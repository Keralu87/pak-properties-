import { useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { PROPERTIES, type PropertyType, type ListingPurpose } from "@/data/properties";
import PropertyCard from "@/components/PropertyCard";
import FilterPanel, { defaultFilters, type FilterState } from "@/components/FilterPanel";
import AdBanner from "@/components/AdBanner";
import { Filter, Search } from "@/components/Icons";

export default function SearchPage() {
  const [params, setParams] = useSearchParams();
  const isRentPath = location.pathname === "/rent";
  const isBuyPath = location.pathname === "/buy";
  const [filters, setFilters] = useState<FilterState>(() => ({
    ...defaultFilters,
    purpose:
      (params.get("purpose") as ListingPurpose) ||
      (isRentPath ? "rent" : isBuyPath ? "sale" : "sale"),
    city: params.get("city") || "",
    area: params.get("area") || "",
    type: (params.get("type") as PropertyType) || "",
    bedrooms: params.get("bedrooms") || "any",
    q: params.get("q") || "",
  }));
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);
  const [sort, setSort] = useState("newest");

  useEffect(() => {
    const newParams: Record<string, string> = {};
    if (filters.purpose) newParams.purpose = filters.purpose;
    if (filters.city) newParams.city = filters.city;
    if (filters.area) newParams.area = filters.area;
    if (filters.type) newParams.type = filters.type;
    if (filters.bedrooms && filters.bedrooms !== "any") newParams.bedrooms = filters.bedrooms;
    if (filters.q) newParams.q = filters.q;
    setParams(newParams, { replace: true });
  }, [filters, setParams]);

  const results = useMemo(() => {
    let list = PROPERTIES.filter((p) => {
      if (filters.purpose && p.purpose !== filters.purpose) return false;
      if (filters.city && p.city !== filters.city) return false;
      if (filters.area && p.area_name !== filters.area) return false;
      if (filters.type && p.type !== filters.type) return false;
      if (filters.bedrooms !== "any" && filters.bedrooms !== "") {
        const b = parseInt(filters.bedrooms);
        if (filters.bedrooms === "5+") {
          if (p.bedrooms < 5) return false;
        } else if (p.bedrooms !== b) return false;
      }
      if (filters.minPrice && p.price < parseInt(filters.minPrice)) return false;
      if (filters.maxPrice && p.price > parseInt(filters.maxPrice)) return false;
      if (filters.minArea && p.area < parseInt(filters.minArea)) return false;
      if (filters.maxArea && p.area > parseInt(filters.maxArea)) return false;
      if (filters.tier === "featured" && !(p.featured || p.premium)) return false;
      if (filters.tier === "premium" && !p.premium) return false;
      if (filters.q) {
        const q = filters.q.toLowerCase();
        const haystack = `${p.title} ${p.description} ${p.city} ${p.area_name} ${p.address}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });

    list = [...list].sort((a, b) => {
      switch (sort) {
        case "price-low":
          return a.price - b.price;
        case "price-high":
          return b.price - a.price;
        case "area":
          return b.area - a.area;
        case "newest":
        default:
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      }
    });

    return list;
  }, [filters, sort]);

  return (
    <div className="bg-slate-50">
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-6 lg:px-8">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h1 className="text-2xl font-bold text-slate-900">
                {results.length} {filters.purpose === "sale" ? "Properties for Sale" : "Properties for Rent"}
                {filters.city && ` in ${filters.city}`}
              </h1>
              <p className="mt-1 text-sm text-slate-600">
                Showing verified listings from trusted real estate agents
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2">
                <label className="text-sm text-slate-600">Sort by:</label>
                <select
                  value={sort}
                  onChange={(e) => setSort(e.target.value)}
                  className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
                >
                  <option value="newest">Newest</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="area">Largest Area</option>
                </select>
              </div>
              <button
                onClick={() => setMobileFiltersOpen(true)}
                className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-medium lg:hidden"
              >
                <Filter width={16} height={16} />
                Filters
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-6 lg:px-8">
        <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
          <aside className="hidden lg:block">
            <FilterPanel filters={filters} setFilters={setFilters} />
          </aside>

          <main className="space-y-6">
            {results.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center">
                <Search width={48} height={48} className="mx-auto text-slate-300" />
                <h3 className="mt-4 text-lg font-semibold text-slate-900">No properties found</h3>
                <p className="mt-1 text-sm text-slate-500">
                  Try adjusting your filters or search in a different city.
                </p>
                <Link
                  to="/"
                  className="mt-4 inline-flex rounded-lg bg-emerald-600 px-6 py-2 text-sm font-semibold text-white transition hover:bg-emerald-700"
                >
                  Browse all listings
                </Link>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-3">
                  {results.slice(0, 9).map((p) => (
                    <PropertyCard key={p.id} property={p} />
                  ))}
                </div>
                <AdBanner variant="horizontal" />
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-3">
                  {results.slice(9).map((p) => (
                    <PropertyCard key={p.id} property={p} />
                  ))}
                </div>
              </>
            )}
          </main>
        </div>
      </div>

      {/* Mobile filter drawer */}
      {mobileFiltersOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setMobileFiltersOpen(false)}
          />
          <div className="absolute inset-y-0 right-0 w-full max-w-sm overflow-y-auto bg-white p-4">
            <FilterPanel
              filters={filters}
              setFilters={setFilters}
              isMobile
              onClose={() => setMobileFiltersOpen(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
}
