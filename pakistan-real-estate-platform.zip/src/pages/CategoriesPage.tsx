import { Link } from "react-router-dom";
import { PROPERTIES, PROPERTY_TYPES, type PropertyType } from "@/data/properties";
import PropertyCard from "@/components/PropertyCard";
import AdBanner from "@/components/AdBanner";

interface CategoryPageProps {
  type: PropertyType;
}

export default function CategoryPage({ type }: CategoryPageProps) {
  const meta = PROPERTY_TYPES.find((p) => p.value === type);
  const listings = PROPERTIES.filter((p) => p.type === type);
  const forSale = listings.filter((p) => p.purpose === "sale").length;
  const forRent = listings.filter((p) => p.purpose === "rent").length;

  return (
    <div className="bg-slate-50">
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
          <span className="text-sm text-slate-500">
            <Link to="/" className="hover:text-emerald-700">Home</Link>
            <span className="mx-2">/</span>
            <Link to="/search" className="hover:text-emerald-700">Properties</Link>
            <span className="mx-2">/</span>
            <span className="text-slate-700">{meta?.label}</span>
          </span>
          <div className="mt-2 flex items-center gap-3">
            <span className="text-4xl">{meta?.icon}</span>
            <div>
              <h1 className="text-3xl font-bold text-slate-900 lg:text-4xl">{meta?.label} for Sale & Rent</h1>
              <p className="mt-1 text-sm text-slate-600">
                Browse {listings.length} verified {meta?.label.toLowerCase()} listings across Pakistan
              </p>
            </div>
          </div>

          <div className="mt-4 flex gap-2">
            <Link
              to={`/search?type=${type}&purpose=sale`}
              className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white"
            >
              {forSale} For Sale
            </Link>
            <Link
              to={`/search?type=${type}&purpose=rent`}
              className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700"
            >
              {forRent} For Rent
            </Link>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {listings.map((p) => (
            <PropertyCard key={p.id} property={p} />
          ))}
        </div>
        <div className="mt-8">
          <AdBanner variant="horizontal" />
        </div>
      </div>
    </div>
  );
}
