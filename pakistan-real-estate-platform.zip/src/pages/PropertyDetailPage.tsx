import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { getPropertyById, PROPERTIES } from "@/data/properties";
import PropertyCard from "@/components/PropertyCard";
import PropertyMap from "@/components/PropertyMap";
import AdBanner from "@/components/AdBanner";
import { useStore } from "@/utils/store";
import { formatArea, formatDate, formatPrice } from "@/utils/format";
import {
  Bath,
  Bed,
  Building,
  Calendar,
  CheckCircle,
  Heart,
  Home as HomeIcon,
  Mail,
  MapPin,
  Phone,
  Shield,
  Square,
  Star,
  TreePine,
} from "@/components/Icons";

const TYPE_ICON: Record<string, React.ReactElement> = {
  house: <HomeIcon width={18} height={18} />,
  apartment: <Building width={18} height={18} />,
  commercial: <Building width={18} height={18} />,
  plot: <Square width={18} height={18} />,
  farmhouse: <TreePine width={18} height={18} />,
};

export default function PropertyDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const property = id ? getPropertyById(id) : null;
  const { isFavorite, toggleFavorite } = useStore();
  const [imgIdx, setImgIdx] = useState(0);

  if (!property) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-slate-900">Property not found</h2>
        <p className="mt-2 text-slate-600">The listing you're looking for may have been removed.</p>
        <button
          onClick={() => navigate("/search")}
          className="mt-6 inline-flex rounded-lg bg-emerald-600 px-5 py-2.5 font-semibold text-white"
        >
          Browse all properties
        </button>
      </div>
    );
  }

  const fav = isFavorite(property.id);
  const similar = PROPERTIES.filter(
    (p) => p.id !== property.id && p.type === property.type && p.city === property.city
  ).slice(0, 3);

  return (
    <div className="bg-slate-50">
      {/* Breadcrumb */}
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-7xl items-center gap-2 px-4 py-3 text-sm text-slate-500 lg:px-8">
          <Link to="/" className="hover:text-emerald-700">
            Home
          </Link>
          <span>/</span>
          <Link to="/search" className="hover:text-emerald-700">
            {property.purpose === "sale" ? "Buy" : "Rent"}
          </Link>
          <span>/</span>
          <Link to={`/search?city=${encodeURIComponent(property.city)}`} className="hover:text-emerald-700">
            {property.city}
          </Link>
          <span>/</span>
          <span className="line-clamp-1 text-slate-700">{property.title}</span>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-6 lg:px-8">
        {/* Header */}
        <div className="mb-4 flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-700">
                <MapPin width={12} height={12} />
                {property.area_name}, {property.city}
              </span>
              {property.premium && (
                <span className="inline-flex items-center gap-1 rounded-full bg-gradient-to-r from-amber-400 to-orange-500 px-3 py-1 text-xs font-bold text-white">
                  <Star width={12} height={12} filled /> Premium
                </span>
              )}
              {property.featured && !property.premium && (
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-600 px-3 py-1 text-xs font-bold text-white">
                  <Star width={12} height={12} filled /> Featured
                </span>
              )}
              <span className="rounded-full bg-slate-900 px-3 py-1 text-xs font-semibold text-white">
                For {property.purpose === "sale" ? "Sale" : "Rent"}
              </span>
            </div>
            <h1 className="mt-2 text-2xl font-bold text-slate-900 lg:text-3xl">{property.title}</h1>
            <div className="mt-2 flex items-center gap-2 text-sm text-slate-500">
              <Calendar width={14} height={14} />
              Listed on {formatDate(property.created_at)}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="text-3xl font-bold text-emerald-700 lg:text-4xl">
                {formatPrice(property.price, property.purpose)}
              </div>
              <div className="text-xs text-slate-500">
                {property.purpose === "sale" ? "Total price" : "Monthly rent"}
              </div>
            </div>
            <button
              onClick={() => toggleFavorite(property.id)}
              className={`flex h-12 w-12 items-center justify-center rounded-xl border-2 transition ${
                fav
                  ? "border-rose-300 bg-rose-50 text-rose-600"
                  : "border-slate-200 bg-white text-slate-700 hover:border-rose-300"
              }`}
              aria-label={fav ? "Remove from favorites" : "Add to favorites"}
            >
              <Heart width={22} height={22} filled={fav} />
            </button>
          </div>
        </div>

        {/* Image gallery */}
        <div className="grid gap-2 lg:grid-cols-4 lg:grid-rows-2">
          <button
            onClick={() => setImgIdx(0)}
            className={`relative aspect-[16/10] overflow-hidden rounded-2xl ring-2 ring-transparent transition lg:col-span-2 lg:row-span-2 lg:aspect-auto ${
              imgIdx === 0 ? "ring-emerald-500" : ""
            }`}
          >
            <img
              src={property.images[0]}
              alt={property.title}
              className="h-full w-full object-cover transition hover:scale-105"
            />
          </button>
          {property.images.slice(1, 5).map((img, idx) => (
            <button
              key={idx}
              onClick={() => setImgIdx(idx + 1)}
              className={`relative hidden aspect-[16/10] overflow-hidden rounded-2xl ring-2 ring-transparent transition lg:block ${
                imgIdx === idx + 1 ? "ring-emerald-500" : ""
              }`}
            >
              <img
                src={img}
                alt={`Property ${idx + 2}`}
                className="h-full w-full object-cover transition hover:scale-105"
              />
              {idx === 3 && property.images.length > 5 && (
                <div className="absolute inset-0 flex items-center justify-center bg-slate-900/50 text-white">
                  <span className="text-sm font-semibold">+{property.images.length - 5} more</span>
                </div>
              )}
            </button>
          ))}
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_360px]">
          <div className="space-y-6">
            {/* Key facts */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6">
              <h2 className="mb-4 text-lg font-bold text-slate-900">Property Overview</h2>
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                <div className="rounded-xl bg-slate-50 p-4 text-center">
                  <div className="flex justify-center text-emerald-600">{TYPE_ICON[property.type]}</div>
                  <div className="mt-2 text-xs text-slate-500">Type</div>
                  <div className="text-sm font-semibold capitalize text-slate-900">{property.type}</div>
                </div>
                {property.bedrooms > 0 && (
                  <div className="rounded-xl bg-slate-50 p-4 text-center">
                    <div className="flex justify-center text-emerald-600"><Bed width={20} height={20} /></div>
                    <div className="mt-2 text-xs text-slate-500">Bedrooms</div>
                    <div className="text-sm font-semibold text-slate-900">{property.bedrooms}</div>
                  </div>
                )}
                {property.bathrooms > 0 && (
                  <div className="rounded-xl bg-slate-50 p-4 text-center">
                    <div className="flex justify-center text-emerald-600"><Bath width={20} height={20} /></div>
                    <div className="mt-2 text-xs text-slate-500">Bathrooms</div>
                    <div className="text-sm font-semibold text-slate-900">{property.bathrooms}</div>
                  </div>
                )}
                <div className="rounded-xl bg-slate-50 p-4 text-center">
                  <div className="flex justify-center text-emerald-600"><Square width={20} height={20} /></div>
                  <div className="mt-2 text-xs text-slate-500">Area</div>
                  <div className="text-sm font-semibold text-slate-900">{formatArea(property.area)}</div>
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6">
              <h2 className="mb-3 text-lg font-bold text-slate-900">Description</h2>
              <p className="leading-relaxed text-slate-700">{property.description}</p>
            </div>

            {/* Features */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6">
              <h2 className="mb-4 text-lg font-bold text-slate-900">Amenities & Features</h2>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {property.features.map((f, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <CheckCircle width={18} height={18} className="text-emerald-600" />
                    <span className="text-sm text-slate-700">{f}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Map */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6">
              <h2 className="mb-3 text-lg font-bold text-slate-900">Location</h2>
              <PropertyMap
                lat={property.coordinates.lat}
                lng={property.coordinates.lng}
                address={property.address}
              />
            </div>

            {/* Similar */}
            {similar.length > 0 && (
              <div>
                <h2 className="mb-4 text-lg font-bold text-slate-900">Similar Properties</h2>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {similar.map((p) => (
                    <PropertyCard key={p.id} property={p} compact />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
            {/* Trust badge */}
            <div className="flex items-center gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
              <Shield width={24} height={24} className="text-emerald-700" />
              <div>
                <div className="text-sm font-semibold text-emerald-900">Verified Listing</div>
                <div className="text-xs text-emerald-700">
                  Identity & documents verified by PakProperties
                </div>
              </div>
            </div>

            {/* Agent card */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6">
              <div className="flex items-center gap-3">
                <img
                  src={property.agent.avatar}
                  alt={property.agent.name}
                  className="h-14 w-14 rounded-full"
                />
                <div>
                  <div className="font-semibold text-slate-900">{property.agent.name}</div>
                  <div className="text-xs text-slate-500">{property.agent.agency}</div>
                  <div className="text-xs text-slate-500">
                    {property.agent.experience}+ years experience
                  </div>
                </div>
              </div>
              <a
                href={`tel:${property.agent.phone}`}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-700"
              >
                <Phone width={16} height={16} />
                {property.agent.phone}
              </a>
              <a
                href={`mailto:${property.agent.email}`}
                className="mt-2 flex w-full items-center justify-center gap-2 rounded-lg border border-slate-200 px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
              >
                <Mail width={16} height={16} />
                Email agent
              </a>

              <form
                onSubmit={(e) => e.preventDefault()}
                className="mt-4 space-y-2 border-t border-slate-200 pt-4"
              >
                <input
                  type="text"
                  placeholder="Your name"
                  className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
                />
                <input
                  type="tel"
                  placeholder="Your phone"
                  className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
                />
                <textarea
                  placeholder={`I'm interested in "${property.title}". Please contact me.`}
                  rows={3}
                  className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
                />
                <button
                  type="submit"
                  className="w-full rounded-lg bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-slate-800"
                >
                  Send Inquiry
                </button>
              </form>
            </div>

            <AdBanner variant="square" />
          </aside>
        </div>
      </div>
    </div>
  );
}
