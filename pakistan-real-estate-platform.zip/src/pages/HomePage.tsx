import { Link } from "react-router-dom";
import { PROPERTIES, PROPERTY_TYPES, CITIES, getPremiumProperties, getFeaturedProperties } from "@/data/properties";
import PropertyCard from "@/components/PropertyCard";
import HomeSearchBar from "@/components/HomeSearchBar";
import AdBanner from "@/components/AdBanner";
import {
  CheckCircle,
  ChevronRight,
  Home as HomeIcon,
  MapPin,
  Shield,
  Star,
  TrendingUp,
} from "@/components/Icons";

export default function HomePage() {
  const featured = getFeaturedProperties();
  const premium = getPremiumProperties().slice(0, 4);
  const totalListings = PROPERTIES.length + 420;

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-900 text-white">
        <div className="absolute inset-0 opacity-15">
          <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
                <path d="M 60 0 L 0 0 0 60" fill="none" stroke="white" strokeWidth="0.5" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>
        <div className="absolute -right-32 top-1/2 h-96 w-96 -translate-y-1/2 rounded-full bg-emerald-500/30 blur-3xl" />
        <div className="absolute -left-32 bottom-0 h-80 w-80 rounded-full bg-teal-500/20 blur-3xl" />

        <div className="relative mx-auto max-w-7xl px-4 py-16 lg:px-8 lg:py-24">
          <div className="grid items-center gap-10 lg:grid-cols-2">
            <div className="space-y-6">
              <span className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider backdrop-blur">
                <Star width={14} height={14} className="text-amber-300" filled />
                Pakistan's #1 Real Estate Marketplace
              </span>
              <h1 className="text-4xl font-bold leading-tight md:text-5xl lg:text-6xl">
                Find your dream property in <span className="text-amber-300">Pakistan</span>
              </h1>
              <p className="text-lg text-emerald-100">
                Buy, sell, and rent verified properties across Islamabad, Lahore, Karachi, and all major
                Pakistani cities. Over 50,000+ listings from trusted agents.
              </p>

              <div className="grid grid-cols-3 gap-4 pt-2">
                <div>
                  <div className="text-2xl font-bold">{totalListings.toLocaleString("en-PK")}+</div>
                  <div className="text-xs text-emerald-200">Active Listings</div>
                </div>
                <div>
                  <div className="text-2xl font-bold">5,000+</div>
                  <div className="text-xs text-emerald-200">Verified Agents</div>
                </div>
                <div>
                  <div className="text-2xl font-bold">8</div>
                  <div className="text-xs text-emerald-200">Major Cities</div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="absolute -inset-4 rounded-3xl bg-gradient-to-br from-amber-400/20 to-emerald-400/20 blur-2xl" />
              <HomeSearchBar />
            </div>
          </div>
        </div>
      </section>

      {/* Browse by Type */}
      <section className="bg-slate-50 py-12">
        <div className="mx-auto max-w-7xl px-4 lg:px-8">
          <div className="mb-8 flex items-end justify-between">
            <div>
              <h2 className="text-2xl font-bold text-slate-900 lg:text-3xl">Browse by Property Type</h2>
              <p className="mt-1 text-sm text-slate-600">Find exactly what you're looking for</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
            {[
              ...PROPERTY_TYPES,
              { value: "all" as const, label: "All Properties", icon: "🏘️" },
            ].map((t) => (
              <Link
                key={t.value}
                to={t.value === "all" ? "/" : `/${t.value === "house" ? "buy" : t.value === "apartment" ? "rent" : t.value}s`}
                className="group relative flex flex-col items-center justify-center gap-3 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:border-emerald-300 hover:shadow-lg"
              >
                <div className="text-4xl transition group-hover:scale-110">{t.icon}</div>
                <div className="text-center">
                  <div className="font-semibold text-slate-900">{t.label}</div>
                  <div className="text-xs text-slate-500">
                    {Math.floor(Math.random() * 200 + 50)} listings
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Listings */}
      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4 lg:px-8">
          <div className="mb-8 flex items-end justify-between">
            <div>
              <span className="inline-block rounded-full bg-amber-100 px-3 py-1 text-xs font-bold text-amber-700">
                ⭐ FEATURED
              </span>
              <h2 className="mt-2 text-2xl font-bold text-slate-900 lg:text-3xl">Featured Properties</h2>
              <p className="mt-1 text-sm text-slate-600">Hand-picked listings from verified agents</p>
            </div>
            <Link
              to="/search?tier=featured"
              className="hidden items-center gap-1 text-sm font-semibold text-emerald-700 hover:text-emerald-800 lg:flex"
            >
              View all <ChevronRight width={16} height={16} />
            </Link>
          </div>

          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {featured.map((p) => (
              <PropertyCard key={p.id} property={p} />
            ))}
          </div>
        </div>
      </section>

      <AdBanner variant="horizontal" className="mx-auto my-4 max-w-7xl px-4 lg:px-8" />

      {/* Premium */}
      <section className="bg-gradient-to-r from-slate-900 to-slate-800 py-12 text-white">
        <div className="mx-auto max-w-7xl px-4 lg:px-8">
          <div className="mb-8 flex items-end justify-between">
            <div>
              <span className="inline-block rounded-full bg-gradient-to-r from-amber-400 to-orange-500 px-3 py-1 text-xs font-bold text-white">
                ⭐ PREMIUM
              </span>
              <h2 className="mt-2 text-2xl font-bold lg:text-3xl">Premium Listings</h2>
              <p className="mt-1 text-sm text-slate-300">Luxury properties with exclusive features</p>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-4">
            {premium.map((p) => (
              <PropertyCard key={p.id} property={p} compact />
            ))}
          </div>
        </div>
      </section>

      {/* Cities */}
      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4 lg:px-8">
          <div className="mb-8 text-center">
            <h2 className="text-2xl font-bold text-slate-900 lg:text-3xl">Browse by City</h2>
            <p className="mt-1 text-sm text-slate-600">Find properties in Pakistan's top locations</p>
          </div>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {CITIES.map((c, i) => (
              <Link
                key={c.name}
                to={`/buy?city=${encodeURIComponent(c.name)}`}
                className="group relative aspect-[4/3] overflow-hidden rounded-2xl"
              >
                <img
                  src={[
                    "https://images.unsplash.com/photo-1582418702059-97ebd4a4f2b6?w=600&q=80",
                    "https://images.unsplash.com/photo-1518399587215-2f883606f157?w=600&q=80",
                    "https://images.unsplash.com/photo-1528001417342-eca89d7d62ed?w=600&q=80",
                    "https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=600&q=80",
                    "https://images.unsplash.com/photo-1564507592333-c60657eea523?w=600&q=80",
                    "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=600&q=80",
                    "https://images.unsplash.com/photo-1548013146-72479768bada?w=600&q=80",
                    "https://images.unsplash.com/photo-1568667256549-094345857637?w=600&q=80",
                  ][i % 8]}
                  alt={c.name}
                  className="h-full w-full object-cover transition group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <div className="flex items-center gap-1 text-sm font-semibold">
                    <MapPin width={14} height={14} />
                    {c.name}
                  </div>
                  <div className="text-xs text-white/80">
                    {Math.floor(Math.random() * 300 + 100)} properties
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Why us */}
      <section className="bg-slate-50 py-12">
        <div className="mx-auto max-w-7xl px-4 lg:px-8">
          <div className="mb-8 text-center">
            <h2 className="text-2xl font-bold text-slate-900 lg:text-3xl">Why Choose PakProperties?</h2>
            <p className="mt-1 text-sm text-slate-600">Trusted by thousands of buyers, sellers, and renters</p>
          </div>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {
                icon: <Shield width={28} height={28} />,
                color: "bg-emerald-100 text-emerald-700",
                title: "Verified Listings",
                text: "Every property is verified by our team before going live.",
              },
              {
                icon: <CheckCircle width={28} height={28} />,
                color: "bg-blue-100 text-blue-700",
                title: "Trusted Agents",
                text: "Work with certified real estate professionals.",
              },
              {
                icon: <TrendingUp width={28} height={28} />,
                color: "bg-amber-100 text-amber-700",
                title: "Market Insights",
                text: "Get the latest market trends and price analysis.",
              },
              {
                icon: <HomeIcon width={28} height={28} />,
                color: "bg-rose-100 text-rose-700",
                title: "50,000+ Listings",
                text: "Largest inventory of properties across Pakistan.",
              },
            ].map((item, idx) => (
              <div
                key={idx}
                className="rounded-2xl bg-white p-6 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
              >
                <div className={`mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl ${item.color}`}>
                  {item.icon}
                </div>
                <h3 className="mb-1 font-semibold text-slate-900">{item.title}</h3>
                <p className="text-sm text-slate-600">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories showcase */}
      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4 lg:px-8">
          <h2 className="mb-8 text-2xl font-bold text-slate-900 lg:text-3xl">Explore Categories</h2>
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
            {[
              { type: "house", img: "1568605114967-8130f3a36994" },
              { type: "apartment", img: "1502672260266-1c1ef2d93688" },
              { type: "commercial", img: "1497366216548-37526070297c" },
              { type: "plot", img: "1500382017468-9049fed747ef" },
              { type: "farmhouse", img: "1600585153086-00f18efc2291" },
            ].map((cat) => {
              const meta = PROPERTY_TYPES.find((p) => p.value === cat.type);
              return (
                <Link
                  key={cat.type}
                  to={`/${cat.type}s`}
                  className="group relative aspect-[3/4] overflow-hidden rounded-2xl"
                >
                  <img
                    src={`https://images.unsplash.com/photo-${cat.img}?auto=format&fit=crop&w=500&q=80`}
                    alt={meta?.label}
                    className="h-full w-full object-cover transition group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4 text-white">
                    <div className="text-3xl">{meta?.icon}</div>
                    <div className="text-lg font-bold">{meta?.label}</div>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-br from-emerald-700 to-teal-700 py-12 text-white">
        <div className="mx-auto max-w-4xl px-4 text-center lg:px-8">
          <h2 className="text-3xl font-bold lg:text-4xl">Ready to list your property?</h2>
          <p className="mt-3 text-emerald-100">
            Reach thousands of potential buyers and tenants across Pakistan. Listing is quick, easy, and free!
          </p>
          <div className="mt-6 flex justify-center gap-3">
            <Link
              to="/submit"
              className="rounded-xl bg-white px-6 py-3 font-semibold text-emerald-700 transition hover:bg-emerald-50"
            >
              List your property
            </Link>
            <Link
              to="/search"
              className="rounded-xl border-2 border-white/30 px-6 py-3 font-semibold text-white transition hover:bg-white/10"
            >
              Browse all properties
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
