import { Link } from "react-router-dom";
import { useStore } from "@/utils/store";
import { PROPERTIES } from "@/data/properties";
import PropertyCard from "@/components/PropertyCard";
import AdBanner from "@/components/AdBanner";
import { Heart } from "@/components/Icons";

export default function FavoritesPage() {
  const { favorites } = useStore();
  const favoriteProperties = PROPERTIES.filter((p) => favorites.includes(p.id));

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
      <div className="mb-6 flex items-center gap-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-rose-100 text-rose-600">
          <Heart width={24} height={24} filled />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-slate-900 lg:text-3xl">My Favorites</h1>
          <p className="text-sm text-slate-600">
            {favorites.length} saved {favorites.length === 1 ? "property" : "properties"}
          </p>
        </div>
      </div>

      {favoriteProperties.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center">
          <Heart width={48} height={48} className="mx-auto text-slate-300" />
          <h2 className="mt-4 text-xl font-semibold text-slate-900">No favorites yet</h2>
          <p className="mt-1 text-sm text-slate-600">
            Tap the heart icon on any listing to save it here.
          </p>
          <Link
            to="/search"
            className="mt-4 inline-flex rounded-lg bg-emerald-600 px-6 py-2.5 text-sm font-semibold text-white"
          >
            Browse properties
          </Link>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {favoriteProperties.map((p) => (
              <PropertyCard key={p.id} property={p} />
            ))}
          </div>
          <div className="mt-8">
            <AdBanner variant="horizontal" />
          </div>
        </>
      )}
    </div>
  );
}
