import { Link } from "react-router-dom";
import { useStore } from "@/utils/store";
import { PROPERTIES } from "@/data/properties";
import { formatPrice } from "@/utils/format";
import { Heart, Home as HomeIcon, LogOut, Mail, MapPin, User } from "@/components/Icons";

export default function AccountPage() {
  const { user, logout, favorites } = useStore();
  const favoriteProperties = PROPERTIES.filter((p) => favorites.includes(p.id));

  const stats = [
    { label: "Favorites", value: favorites.length, icon: <Heart width={18} height={18} /> },
    { label: "Inquiries", value: 3, icon: <Mail width={18} height={18} /> },
    { label: "Listings", value: 2, icon: <HomeIcon width={18} height={18} /> },
    { label: "Profile Views", value: 142, icon: <User width={18} height={18} /> },
  ];

  if (!user) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-slate-900">Please sign in</h2>
        <p className="mt-2 text-slate-600">You need to be signed in to view your account.</p>
        <Link
          to="/login"
          className="mt-4 inline-flex rounded-lg bg-emerald-600 px-6 py-2.5 font-semibold text-white"
        >
          Sign In
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
      <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-4">
          <img src={user.avatar} alt={user.name} className="h-16 w-16 rounded-full" />
          <div>
            <h1 className="text-2xl font-bold text-slate-900 lg:text-3xl">Hi, {user.name.split(" ")[0]}</h1>
            <p className="text-sm text-slate-600">Welcome back to your PakProperties account</p>
          </div>
        </div>
        <button
          onClick={logout}
          className="inline-flex items-center gap-2 self-start rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
        >
          <LogOut width={16} height={16} />
          Sign out
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s, i) => (
          <div key={i} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                {s.icon}
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-900">{s.value}</div>
                <div className="text-xs text-slate-500">{s.label}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="mb-4 text-lg font-bold text-slate-900">My Favorites</h2>
            {favoriteProperties.length === 0 ? (
              <div className="rounded-xl border border-dashed border-slate-300 p-8 text-center">
                <Heart width={32} height={32} className="mx-auto text-slate-300" />
                <p className="mt-3 text-sm text-slate-600">No favorites yet</p>
                <Link
                  to="/search"
                  className="mt-3 inline-flex rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white"
                >
                  Browse properties
                </Link>
              </div>
            ) : (
              <div className="space-y-3">
                {favoriteProperties.slice(0, 5).map((p) => (
                  <Link
                    key={p.id}
                    to={`/property/${p.id}`}
                    className="flex items-center gap-3 rounded-xl border border-slate-200 p-3 transition hover:border-emerald-300"
                  >
                    <img src={p.images[0]} alt={p.title} className="h-16 w-16 rounded-lg object-cover" />
                    <div className="flex-1">
                      <div className="line-clamp-1 text-sm font-semibold text-slate-900">{p.title}</div>
                      <div className="flex items-center gap-2 text-xs text-slate-500">
                        <MapPin width={10} height={10} />
                        {p.area_name}, {p.city}
                      </div>
                    </div>
                    <div className="text-right text-sm font-bold text-emerald-700">
                      {formatPrice(p.price, p.purpose)}
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>

        <aside className="space-y-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="mb-4 text-lg font-bold text-slate-900">Personal Information</h2>
            <div className="space-y-3 text-sm">
              <div>
                <div className="text-xs text-slate-500">Name</div>
                <div className="font-medium text-slate-900">{user.name}</div>
              </div>
              <div>
                <div className="text-xs text-slate-500">Email</div>
                <div className="font-medium text-slate-900">{user.email}</div>
              </div>
              <div>
                <div className="text-xs text-slate-500">Phone</div>
                <div className="font-medium text-slate-900">{user.phone}</div>
              </div>
              <button className="w-full rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700 transition hover:bg-slate-50">
                Edit Profile
              </button>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="mb-4 text-lg font-bold text-slate-900">Saved Searches</h2>
            <ul className="space-y-2 text-sm">
              {[
                { name: "3-4 Bedroom Houses in Islamabad", newCount: 12 },
                { name: "Apartments for Rent in DHA Lahore", newCount: 5 },
              ].map((s, i) => (
                <li key={i} className="flex items-center justify-between rounded-lg bg-slate-50 p-3">
                  <span className="text-slate-700">{s.name}</span>
                  <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-semibold text-emerald-700">
                    {s.newCount} new
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </aside>
      </div>
    </div>
  );
}
