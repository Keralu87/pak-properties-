import { useState, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { CITIES, PROPERTY_TYPES } from "@/data/properties";
import { Camera, CheckCircle } from "@/components/Icons";

const STEPS = ["Property Type", "Details", "Location", "Photos", "Review"] as const;

export default function SubmitPropertyPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    purpose: "sale" as "sale" | "rent",
    type: "house" as string,
    title: "",
    description: "",
    price: "",
    bedrooms: "3",
    bathrooms: "3",
    area: "",
    city: "",
    area_name: "",
    address: "",
    agent_name: "",
    agent_phone: "",
    agent_email: "",
    features: [] as string[],
  });

  const update = (patch: Partial<typeof form>) => setForm({ ...form, ...patch });

  const next = () => setStep((s) => Math.min(s + 1, STEPS.length - 1));
  const prev = () => setStep((s) => Math.max(s - 1, 0));

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => navigate("/"), 3000);
  };

  if (submitted) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center">
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-12">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500 text-white">
            <CheckCircle width={36} height={36} />
          </div>
          <h2 className="mt-4 text-2xl font-bold text-slate-900">Listing submitted!</h2>
          <p className="mt-2 text-slate-600">
            Thank you for submitting your property. Our team will review it within 24 hours and publish it shortly.
          </p>
          <div className="mt-6 inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-medium text-slate-700">
            <div className="h-2 w-2 animate-pulse rounded-full bg-emerald-500" />
            Redirecting to homepage...
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 lg:px-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900 lg:text-3xl">Submit a Property</h1>
        <p className="text-sm text-slate-600">List your property in front of thousands of buyers</p>
      </div>

      {/* Steps */}
      <div className="mb-6 flex items-center gap-2 overflow-x-auto pb-2">
        {STEPS.map((label, i) => (
          <button
            key={label}
            onClick={() => i <= step && setStep(i)}
            className={`flex min-w-fit items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold transition ${
              i === step
                ? "bg-emerald-600 text-white"
                : i < step
                  ? "bg-emerald-100 text-emerald-700"
                  : "bg-slate-100 text-slate-500"
            }`}
          >
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-white/30 text-[10px] font-bold">
              {i + 1}
            </span>
            {label}
          </button>
        ))}
      </div>

      <form onSubmit={onSubmit} className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        {step === 0 && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-slate-900">Listing Type</h2>
            <div className="grid grid-cols-2 gap-2">
              {[
                { v: "sale", l: "For Sale", d: "Sell your property" },
                { v: "rent", l: "For Rent", d: "Rent out your property" },
              ].map((opt) => (
                <button
                  type="button"
                  key={opt.v}
                  onClick={() => update({ purpose: opt.v as "sale" | "rent" })}
                  className={`rounded-lg border-2 p-4 text-left transition ${
                    form.purpose === opt.v
                      ? "border-emerald-500 bg-emerald-50"
                      : "border-slate-200 hover:border-emerald-300"
                  }`}
                >
                  <div className="font-semibold text-slate-900">{opt.l}</div>
                  <div className="text-xs text-slate-500">{opt.d}</div>
                </button>
              ))}
            </div>

            <h2 className="pt-2 text-lg font-bold text-slate-900">Property Type</h2>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {PROPERTY_TYPES.map((t) => (
                <button
                  type="button"
                  key={t.value}
                  onClick={() => update({ type: t.value })}
                  className={`rounded-lg border-2 p-3 text-center transition ${
                    form.type === t.value
                      ? "border-emerald-500 bg-emerald-50"
                      : "border-slate-200 hover:border-emerald-300"
                  }`}
                >
                  <div className="text-2xl">{t.icon}</div>
                  <div className="mt-1 text-sm font-semibold text-slate-900">{t.label}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 1 && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-slate-900">Property Details</h2>
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-700">Listing Title</label>
              <input
                type="text"
                value={form.title}
                onChange={(e) => update({ title: e.target.value })}
                placeholder="e.g. Beautiful 5-Bedroom Villa in DHA"
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-700">Description</label>
              <textarea
                value={form.description}
                onChange={(e) => update({ description: e.target.value })}
                rows={5}
                placeholder="Describe your property, its key features, nearby amenities..."
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">
                  Price (PKR)
                </label>
                <input
                  type="number"
                  value={form.price}
                  onChange={(e) => update({ price: e.target.value })}
                  placeholder="e.g. 50000000"
                  className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Area (sqft)</label>
                <input
                  type="number"
                  value={form.area}
                  onChange={(e) => update({ area: e.target.value })}
                  placeholder="e.g. 5000"
                  className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
                />
              </div>
              {form.type !== "plot" && form.type !== "commercial" && (
                <>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Bedrooms</label>
                    <input
                      type="number"
                      value={form.bedrooms}
                      onChange={(e) => update({ bedrooms: e.target.value })}
                      className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Bathrooms</label>
                    <input
                      type="number"
                      value={form.bathrooms}
                      onChange={(e) => update({ bathrooms: e.target.value })}
                      className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
                    />
                  </div>
                </>
              )}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-slate-900">Location</h2>
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-700">City</label>
              <select
                value={form.city}
                onChange={(e) => update({ city: e.target.value, area_name: "" })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
              >
                <option value="">Select City</option>
                {CITIES.map((c) => (
                  <option key={c.name} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-700">Area / Locality</label>
              <select
                value={form.area_name}
                onChange={(e) => update({ area_name: e.target.value })}
                disabled={!form.city}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none disabled:bg-slate-50"
              >
                <option value="">Select Area</option>
                {form.city &&
                  CITIES.find((c) => c.name === form.city)?.areas.map((a) => (
                    <option key={a} value={a}>
                      {a}
                    </option>
                  ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-700">Full Address</label>
              <textarea
                value={form.address}
                onChange={(e) => update({ address: e.target.value })}
                rows={3}
                placeholder="Street address, landmarks, etc."
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-slate-900">Photos & Agent Info</h2>
            <div className="rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 p-10 text-center">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-white text-slate-400">
                <Camera width={28} height={28} />
              </div>
              <p className="mt-3 text-sm font-semibold text-slate-700">Drag & drop photos here</p>
              <p className="text-xs text-slate-500">JPG or PNG, up to 20 photos. Higher quality photos get more views.</p>
              <button
                type="button"
                className="mt-3 inline-flex rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white"
              >
                Choose files
              </button>
            </div>

            <div className="grid grid-cols-1 gap-3 border-t border-slate-200 pt-4 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Agent Name</label>
                <input
                  type="text"
                  value={form.agent_name}
                  onChange={(e) => update({ agent_name: e.target.value })}
                  placeholder="Your name"
                  className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Agent Phone</label>
                <input
                  type="tel"
                  value={form.agent_phone}
                  onChange={(e) => update({ agent_phone: e.target.value })}
                  placeholder="+92 300 1234567"
                  className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="mb-1 block text-xs font-semibold text-slate-700">Agent Email</label>
                <input
                  type="email"
                  value={form.agent_email}
                  onChange={(e) => update({ agent_email: e.target.value })}
                  placeholder="email@example.com"
                  className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-slate-900">Review Your Listing</h2>
            <div className="space-y-2 rounded-xl bg-slate-50 p-4 text-sm">
              <Row label="Type" value={`${form.purpose === "sale" ? "For Sale" : "For Rent"} · ${form.type}`} />
              <Row label="Title" value={form.title || "—"} />
              <Row label="Price" value={form.price ? `PKR ${parseInt(form.price).toLocaleString("en-PK")}` : "—"} />
              <Row label="Area" value={form.area ? `${form.area} sqft` : "—"} />
              <Row label="Bedrooms" value={form.bedrooms} />
              <Row label="Bathrooms" value={form.bathrooms} />
              <Row label="Location" value={`${form.area_name}${form.area_name && form.city ? ", " : ""}${form.city}`} />
              <Row label="Address" value={form.address || "—"} />
              <Row label="Agent" value={form.agent_name || "—"} />
              <Row label="Contact" value={`${form.agent_phone} · ${form.agent_email}`} />
            </div>
            <p className="text-xs text-slate-500">
              By submitting, you confirm that all information provided is accurate and that you own the rights to publish this listing.
            </p>
          </div>
        )}

        {/* Buttons */}
        <div className="mt-6 flex justify-between border-t border-slate-200 pt-4">
          <button
            type="button"
            onClick={prev}
            disabled={step === 0}
            className="rounded-lg border border-slate-200 px-5 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 disabled:opacity-40"
          >
            Back
          </button>
          {step < STEPS.length - 1 ? (
            <button
              type="button"
              onClick={next}
              className="rounded-lg bg-emerald-600 px-5 py-2 text-sm font-semibold text-white transition hover:bg-emerald-700"
            >
              Continue
            </button>
          ) : (
            <button
              type="submit"
              className="rounded-lg bg-emerald-600 px-5 py-2 text-sm font-semibold text-white transition hover:bg-emerald-700"
            >
              Submit Listing
            </button>
          )}
        </div>
      </form>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-4 border-b border-slate-200 py-1 last:border-b-0">
      <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">{label}</span>
      <span className="text-right text-sm text-slate-800">{value || "—"}</span>
    </div>
  );
}
