import { useState } from "react";
import { Link } from "react-router-dom";
import { PROPERTIES } from "@/data/properties";
import { useStore } from "@/utils/store";
import { formatPrice } from "@/utils/format";
import AdBanner from "@/components/AdBanner";
import {
  Building,
  Eye,
  Home as HomeIcon,
  Megaphone,
  Plus,
  Star,
  TrendingUp,
  User,
} from "@/components/Icons";

export default function AdminPage() {
  const { user, isAdmin } = useStore();
  const [activeTab, setActiveTab] = useState("overview");

  if (!user) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-slate-900">Admin login required</h2>
        <p className="mt-2 text-slate-600">Please sign in to access the admin dashboard.</p>
        <Link
          to="/login"
          className="mt-4 inline-flex rounded-lg bg-emerald-600 px-6 py-2.5 font-semibold text-white"
        >
          Sign In
        </Link>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center">
        <div className="rounded-2xl border border-amber-200 bg-amber-50 p-12">
          <h2 className="text-2xl font-bold text-amber-900">Access Restricted</h2>
          <p className="mt-2 text-amber-700">
            You need admin privileges to access this page. Sign in with an admin email (containing "admin") to gain access.
          </p>
          <Link
            to="/login"
            className="mt-4 inline-flex rounded-lg bg-amber-700 px-6 py-2.5 font-semibold text-white"
          >
            Switch Account
          </Link>
        </div>
      </div>
    );
  }

  const stats = [
    { label: "Total Listings", value: PROPERTIES.length, icon: <HomeIcon width={20} height={20} />, color: "bg-emerald-100 text-emerald-700" },
    { label: "Premium Listings", value: PROPERTIES.filter((p) => p.premium).length, icon: <Star width={20} height={20} />, color: "bg-amber-100 text-amber-700" },
    { label: "Registered Users", value: 12483, icon: <User width={20} height={20} />, color: "bg-blue-100 text-blue-700" },
    { label: "Pending Reviews", value: 23, icon: <Building width={20} height={20} />, color: "bg-rose-100 text-rose-700" },
  ];

  const tabs = [
    { id: "overview", label: "Overview" },
    { id: "listings", label: "Listings" },
    { id: "users", label: "Users" },
    { id: "ads", label: "Advertisements" },
  ];

  return (
    <div className="bg-slate-50">
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-6 lg:px-8">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-700">
                Admin Dashboard
              </span>
              <h1 className="mt-2 text-2xl font-bold text-slate-900 lg:text-3xl">Welcome, {user.name}</h1>
              <p className="text-sm text-slate-600">Manage listings, users, and platform operations</p>
            </div>
            <Link
              to="/submit"
              className="inline-flex items-center gap-2 self-start rounded-lg bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-700"
            >
              <Plus width={16} height={16} />
              Add Listing
            </Link>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-6 lg:px-8">
        <div className="mb-6 flex gap-1 overflow-x-auto rounded-xl bg-white p-1 shadow-sm">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              className={`flex-1 whitespace-nowrap rounded-lg px-4 py-2 text-sm font-semibold transition ${
                activeTab === t.id
                  ? "bg-emerald-600 text-white"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {activeTab === "overview" && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
              {stats.map((s, i) => (
                <div key={i} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${s.color}`}>
                      {s.icon}
                    </div>
                    <span className="flex items-center gap-1 text-xs font-semibold text-emerald-600">
                      <TrendingUp width={12} height={12} />
                      +12.5%
                    </span>
                  </div>
                  <div className="mt-3 text-3xl font-bold text-slate-900">{s.value.toLocaleString("en-PK")}</div>
                  <div className="text-xs text-slate-500">{s.label}</div>
                </div>
              ))}
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <h3 className="mb-4 text-lg font-bold text-slate-900">Recent Listings</h3>
                <div className="space-y-3">
                  {PROPERTIES.slice(0, 5).map((p) => (
                    <Link
                      key={p.id}
                      to={`/property/${p.id}`}
                      className="flex items-center gap-3 rounded-lg p-2 transition hover:bg-slate-50"
                    >
                      <img src={p.images[0]} alt={p.title} className="h-12 w-12 rounded-lg object-cover" />
                      <div className="flex-1 min-w-0">
                        <div className="truncate text-sm font-semibold text-slate-900">{p.title}</div>
                        <div className="text-xs text-slate-500">
                          {p.city} · {formatPrice(p.price, p.purpose)}
                        </div>
                      </div>
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                        p.premium ? "bg-amber-100 text-amber-700" : p.featured ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-700"
                      }`}>
                        {p.premium ? "Premium" : p.featured ? "Featured" : "Standard"}
                      </span>
                    </Link>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <h3 className="mb-4 text-lg font-bold text-slate-900">Recent Activity</h3>
                <div className="space-y-3 text-sm">
                  {[
                    { text: "New listing posted in DHA Phase 6, Islamabad", time: "5 min ago", icon: <HomeIcon width={14} height={14} /> },
                    { text: "Sarah Ahmed upgraded to Premium", time: "23 min ago", icon: <Star width={14} height={14} /> },
                    { text: "Property #p3 status changed to Pending", time: "1 hr ago", icon: <Eye width={14} height={14} /> },
                    { text: "New user registration: 47 today", time: "2 hr ago", icon: <User width={14} height={14} /> },
                    { text: "Advertisement campaign launched", time: "3 hr ago", icon: <Megaphone width={14} height={14} /> },
                  ].map((a, i) => (
                    <div key={i} className="flex items-start gap-3 rounded-lg p-2 hover:bg-slate-50">
                      <span className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-100 text-emerald-700">
                        {a.icon}
                      </span>
                      <div className="flex-1">
                        <div className="text-slate-700">{a.text}</div>
                        <div className="text-xs text-slate-500">{a.time}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <AdBanner variant="horizontal" />
          </div>
        )}

        {activeTab === "listings" && (
          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="border-b border-slate-200 px-4 py-3 lg:px-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-slate-900">All Listings</h3>
                <input
                  type="text"
                  placeholder="Search listings..."
                  className="rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 text-left text-xs font-semibold text-slate-500 uppercase">
                  <tr>
                    <th className="px-4 py-3 lg:px-6">Property</th>
                    <th className="px-4 py-3">Type</th>
                    <th className="px-4 py-3">City</th>
                    <th className="px-4 py-3">Price</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 lg:px-6">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {PROPERTIES.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50">
                      <td className="px-4 py-4 lg:px-6">
                        <div className="flex items-center gap-3">
                          <img src={p.images[0]} alt={p.title} className="h-10 w-10 rounded-lg object-cover" />
                          <div className="line-clamp-1 max-w-xs font-medium text-slate-900">{p.title}</div>
                        </div>
                      </td>
                      <td className="px-4 py-4 capitalize text-slate-600">{p.type}</td>
                      <td className="px-4 py-4 text-slate-600">{p.city}</td>
                      <td className="px-4 py-4 font-semibold text-emerald-700">
                        {formatPrice(p.price, p.purpose)}
                      </td>
                      <td className="px-4 py-4">
                        <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${
                          p.premium ? "bg-amber-100 text-amber-700" : p.featured ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-700"
                        }`}>
                          {p.premium ? "Premium" : p.featured ? "Featured" : "Standard"}
                        </span>
                      </td>
                      <td className="px-4 py-4 lg:px-6">
                        <Link
                          to={`/property/${p.id}`}
                          className="rounded-lg bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700 transition hover:bg-slate-200"
                        >
                          View
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === "users" && (
          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="border-b border-slate-200 px-4 py-3 lg:px-6">
              <h3 className="text-lg font-bold text-slate-900">Registered Users (12,483)</h3>
            </div>
            <div className="grid grid-cols-1 gap-3 p-4 lg:grid-cols-2">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="flex items-center gap-3 rounded-xl border border-slate-200 p-4">
                  <img
                    src={`https://i.pravatar.cc/150?img=${20 + i}`}
                    alt=""
                    className="h-12 w-12 rounded-full"
                  />
                  <div className="flex-1">
                    <div className="font-semibold text-slate-900">
                      User {String.fromCharCode(65 + i)}. Khan
                    </div>
                    <div className="text-xs text-slate-500">user{i}@example.com · Joined 2025</div>
                  </div>
                  <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-semibold text-emerald-700">
                    Active
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "ads" && (
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-slate-900">Advertisement Spaces</h3>
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              <AdBanner variant="horizontal" />
              <AdBanner variant="square" />
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-6">
              <h4 className="font-semibold text-slate-900">Promote Your Listing</h4>
              <p className="mt-1 text-sm text-slate-600">
                Boost your listings for maximum visibility. Choose from Featured or Premium tiers.
              </p>
              <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
                {[
                  { name: "Featured", price: "PKR 5,000 / week", desc: "Highlighted placement on homepage and search" },
                  { name: "Premium", price: "PKR 15,000 / week", desc: "Top placement with Premium badge & priority support" },
                ].map((p, i) => (
                  <div key={i} className="rounded-xl border border-slate-200 p-4">
                    <div className="font-semibold text-slate-900">{p.name}</div>
                    <div className="mt-1 text-xs text-slate-500">{p.desc}</div>
                    <div className="mt-3 text-lg font-bold text-emerald-700">{p.price}</div>
                    <button className="mt-2 w-full rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white">
                      Activate
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
