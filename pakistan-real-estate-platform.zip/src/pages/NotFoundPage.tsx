import { Link } from "react-router-dom";

export default function NotFoundPage() {
  return (
    <div className="min-h-[calc(100vh-200px)] flex items-center justify-center px-4 py-16">
      <div className="text-center">
        <div className="mb-4 text-9xl font-bold text-slate-200">404</div>
        <h1 className="text-3xl font-bold text-slate-900">Page Not Found</h1>
        <p className="mt-2 text-slate-600">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <Link
          to="/"
          className="mt-6 inline-flex rounded-lg bg-emerald-600 px-6 py-2.5 font-semibold text-white transition hover:bg-emerald-700"
        >
          Back to Home
        </Link>
      </div>
    </div>
  );
}
