import { BrowserRouter, Route, Routes } from "react-router-dom";
import { StoreProvider } from "@/utils/store";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import HomePage from "@/pages/HomePage";
import SearchPage from "@/pages/SearchPage";
import PropertyDetailPage from "@/pages/PropertyDetailPage";
import LoginPage from "@/pages/LoginPage";
import AccountPage from "@/pages/AccountPage";
import FavoritesPage from "@/pages/FavoritesPage";
import SubmitPropertyPage from "@/pages/SubmitPropertyPage";
import AdminPage from "@/pages/AdminPage";
import CategoryPage from "@/pages/CategoriesPage";
import NotFoundPage from "@/pages/NotFoundPage";

export default function App() {
  return (
    <StoreProvider>
      <BrowserRouter>
        <div className="flex min-h-screen flex-col bg-white">
          <Header />
          <main className="flex-1">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/search" element={<SearchPage />} />
              <Route path="/buy" element={<SearchPage />} />
              <Route path="/rent" element={<SearchPage />} />
              <Route path="/houses" element={<CategoryPage type="house" />} />
              <Route path="/apartments" element={<CategoryPage type="apartment" />} />
              <Route path="/commercial" element={<CategoryPage type="commercial" />} />
              <Route path="/plots" element={<CategoryPage type="plot" />} />
              <Route path="/farmhouses" element={<CategoryPage type="farmhouse" />} />
              <Route path="/property/:id" element={<PropertyDetailPage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/account" element={<AccountPage />} />
              <Route path="/favorites" element={<FavoritesPage />} />
              <Route path="/submit" element={<SubmitPropertyPage />} />
              <Route path="/admin" element={<AdminPage />} />
              <Route path="*" element={<NotFoundPage />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </BrowserRouter>
    </StoreProvider>
  );
}
