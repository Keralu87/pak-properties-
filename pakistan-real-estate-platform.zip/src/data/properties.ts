export type PropertyType = "house" | "apartment" | "commercial" | "plot" | "farmhouse";
export type ListingPurpose = "sale" | "rent";
export type ListingTier = "standard" | "featured" | "premium";

export interface Property {
  id: string;
  title: string;
  description: string;
  price: number;
  purpose: ListingPurpose;
  type: PropertyType;
  bedrooms: number;
  bathrooms: number;
  area: number; // in square feet
  city: string;
  area_name: string;
  address: string;
  coordinates: { lat: number; lng: number };
  images: string[];
  features: string[];
  featured: boolean;
  premium: boolean;
  tier: ListingTier;
  agent: Agent;
  created_at: string;
}

export interface Agent {
  id: string;
  name: string;
  phone: string;
  email: string;
  avatar: string;
  agency: string;
  experience: number;
}

export const CITIES = [
  { name: "Islamabad", areas: ["F-7", "F-8", "F-10", "F-11", "E-11", "G-10", "G-11", "DHA", "Bahria Town", "Gulberg Greens"] },
  { name: "Rawalpindi", areas: ["Saddar", "Bahria Town", "DHA", "Westridge", "Chaklala", "Satellite Town", "Gulraiz"] },
  { name: "Lahore", areas: ["DHA", "Bahria Town", "Gulberg", "Model Town", "Johar Town", "Defence", "Cantt", "Lake City"] },
  { name: "Karachi", areas: ["DHA", "Clifton", "Gulshan-e-Iqbal", "North Nazimabad", "Bahadurabad", "PECHS", "Bahria Town"] },
  { name: "Peshawar", areas: ["Hayatabad", "University Town", "Cantt", "Saddar", "Gulbahar"] },
  { name: "Faisalabad", areas: ["DHA", "Madina Town", "People's Colony", "Cantt", "Gulberg"] },
  { name: "Multan", areas: ["DHA", "Gulgasht Colony", "Cantt", "Bosan Road", "Shah Rukn-e-Alam"] },
  { name: "Gujranwala", areas: ["DHA", "Cantt", "Sattellite Town", "Model Town", "Civil Lines"] },
];

export const PROPERTY_TYPES: { value: PropertyType; label: string; icon: string }[] = [
  { value: "house", label: "House", icon: "🏠" },
  { value: "apartment", label: "Apartment", icon: "🏢" },
  { value: "commercial", label: "Commercial", icon: "🏬" },
  { value: "plot", label: "Plot", icon: "📐" },
  { value: "farmhouse", label: "Farmhouse", icon: "🌳" },
];

export const BEDROOM_OPTIONS = [
  { value: "any", label: "Any" },
  { value: "1", label: "1" },
  { value: "2", label: "2" },
  { value: "3", label: "3" },
  { value: "4", label: "4" },
  { value: "5+", label: "5+" },
];

const AGENTS: Agent[] = [
  {
    id: "a1",
    name: "Ahmed Sheikh",
    phone: "+92 300 1234567",
    email: "ahmed.sheikh@pakproperties.pk",
    avatar: "https://i.pravatar.cc/150?img=12",
    agency: "PakProperties Islamabad",
    experience: 8,
  },
  {
    id: "a2",
    name: "Sara Khan",
    phone: "+92 321 9876543",
    email: "sara.khan@pakproperties.pk",
    avatar: "https://i.pravatar.cc/150?img=47",
    agency: "PakProperties Lahore",
    experience: 5,
  },
  {
    id: "a3",
    name: "Bilal Malik",
    phone: "+92 333 5551122",
    email: "bilal.malik@pakproperties.pk",
    avatar: "https://i.pravatar.cc/150?img=33",
    agency: "PakProperties Karachi",
    experience: 12,
  },
  {
    id: "a4",
    name: "Fatima Iqbal",
    phone: "+92 345 8880099",
    email: "fatima.iqbal@pakproperties.pk",
    avatar: "https://i.pravatar.cc/150?img=23",
    agency: "PakProperties Rawalpindi",
    experience: 6,
  },
];

// Pseudo-random image generator (uses Unsplash hotlinks, deterministic per id)
const img = (id: string, w = 800) =>
  `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=80`;

export const PROPERTIES: Property[] = [
  {
    id: "p1",
    title: "Luxury 5-Bedroom Villa in DHA Phase 6",
    description:
      "A stunning contemporary villa featuring a private swimming pool, landscaped garden, and smart-home automation. Located in the prestigious DHA Phase 6, this property offers the perfect blend of luxury and comfort with proximity to top schools, malls, and the Islamabad Expressway.",
    price: 185000000,
    purpose: "sale",
    type: "house",
    bedrooms: 5,
    bathrooms: 6,
    area: 6500,
    city: "Islamabad",
    area_name: "DHA",
    address: "Street 14, DHA Phase 6, Islamabad",
    coordinates: { lat: 33.7294, lng: 73.0931 },
    images: [
      img("1564013799919-ab600027ffc6"),
      img("1600585154340-be6161a56a0c"),
      img("1600596542815-ffad4c1539a9"),
      img("1600607687939-ce8a6c25118c"),
    ],
    features: [
      "Swimming Pool",
      "Smart Home",
      "Solar Panels",
      "Double Glazed Windows",
      "Marble Flooring",
      "Walk-in Closet",
      "Servant Quarters",
      "Backup Generator",
    ],
    featured: true,
    premium: true,
    tier: "premium",
    agent: AGENTS[0],
    created_at: "2025-11-20",
  },
  {
    id: "p2",
    title: "Modern 3-Bedroom Apartment in Gulberg",
    description:
      "A bright and airy apartment with panoramic city views in the heart of Gulberg. Featuring an open-concept kitchen, floor-to-ceiling windows, and access to premium amenities including a gym and rooftop terrace.",
    price: 145000,
    purpose: "rent",
    type: "apartment",
    bedrooms: 3,
    bathrooms: 3,
    area: 2200,
    city: "Lahore",
    area_name: "Gulberg",
    address: "Main Boulevard, Gulberg III, Lahore",
    coordinates: { lat: 31.5204, lng: 74.3587 },
    images: [
      img("1502672260266-1c1ef2d93688"),
      img("1560448204-e02f11c3d0e2"),
      img("1493809842364-78817add7ffb"),
    ],
    features: [
      "Central AC",
      "Power Backup",
      "Gym",
      "Rooftop Terrace",
      "24/7 Security",
      "Covered Parking",
    ],
    featured: true,
    premium: false,
    tier: "featured",
    agent: AGENTS[1],
    created_at: "2025-12-01",
  },
  {
    id: "p3",
    title: "10 Marla Residential Plot in Bahria Town",
    description:
      "Prime residential plot in the heart of Bahria Town, ready for immediate construction. The plot faces a wide road and is located near the golf course and commercial area.",
    price: 22000000,
    purpose: "sale",
    type: "plot",
    bedrooms: 0,
    bathrooms: 0,
    area: 2722,
    city: "Rawalpindi",
    area_name: "Bahria Town",
    address: "Sector F, Bahria Town, Rawalpindi",
    coordinates: { lat: 33.5102, lng: 73.2432 },
    images: [
      img("1500382017468-9049fed747ef"),
      img("1564540583246-934409427776"),
    ],
    features: ["Corner Plot", "Wide Road", "Near Park", "Electricity", "Gas", "Water"],
    featured: false,
    premium: false,
    tier: "standard",
    agent: AGENTS[3],
    created_at: "2025-10-15",
  },
  {
    id: "p4",
    title: "Spacious 4-Bedroom House in PECHS Block 6",
    description:
      "A beautifully maintained family home in PECHS with a large lawn, separate servant quarters, and a recently renovated kitchen. Walking distance to schools, parks, and shops.",
    price: 32000000,
    purpose: "sale",
    type: "house",
    bedrooms: 4,
    bathrooms: 4,
    area: 4200,
    city: "Karachi",
    area_name: "PECHS",
    address: "Block 6, PECHS, Karachi",
    coordinates: { lat: 24.8717, lng: 67.0631 },
    images: [
      img("1605146769289-440113cc3d00"),
      img("1570129477492-45c003edd2be"),
      img("1600566753190-17f0baa2a6c3"),
    ],
    features: ["Large Lawn", "Servant Quarters", "Renovated Kitchen", "Car Porch", "Bore Water"],
    featured: true,
    premium: false,
    tier: "featured",
    agent: AGENTS[2],
    created_at: "2025-11-05",
  },
  {
    id: "p5",
    title: "Premium Office Space in Clifton",
    description:
      "Fully furnished office space on the 12th floor with sea views. Ideal for tech companies, consulting firms, or corporate headquarters. Includes reception area, 4 cabins, and an open workspace.",
    price: 850000,
    purpose: "rent",
    type: "commercial",
    bedrooms: 0,
    bathrooms: 2,
    area: 3500,
    city: "Karachi",
    area_name: "Clifton",
    address: "Block 5, Clifton, Karachi",
    coordinates: { lat: 24.8138, lng: 67.0305 },
    images: [
      img("1497366216548-37526070297c"),
      img("1497366811353-6870744d04b2"),
      img("1497366754035-f200968a6e72"),
    ],
    features: ["Sea View", "Furnished", "Central AC", "24/7 Power", "Elevator", "Covered Parking"],
    featured: true,
    premium: true,
    tier: "premium",
    agent: AGENTS[2],
    created_at: "2025-12-10",
  },
  {
    id: "p6",
    title: "Cozy 2-Bedroom Apartment near GPO",
    description:
      "Compact and well-lit apartment ideal for small families or bachelors. Located in a quiet street near the General Post Office, with easy access to public transport.",
    price: 28000,
    purpose: "rent",
    type: "apartment",
    bedrooms: 2,
    bathrooms: 2,
    area: 1100,
    city: "Peshawar",
    area_name: "Saddar",
    address: "Near GPO, Saddar, Peshawar",
    coordinates: { lat: 34.0151, lng: 71.5249 },
    images: [
      img("1522708323590-d24dbb6b0267"),
      img("1554995207-c18c203602cb"),
    ],
    features: ["Furnished", "Generator", "Geyser", "Near Market"],
    featured: false,
    premium: false,
    tier: "standard",
    agent: AGENTS[0],
    created_at: "2025-09-22",
  },
  {
    id: "p7",
    title: "Beautiful 1 Kanal House in Model Town",
    description:
      "A grand 1 Kanal house with 6 bedrooms, a private gym, and a swimming pool. The house features imported fittings, a modern kitchen, and a large garden. Located on a prime street of Model Town.",
    price: 240000000,
    purpose: "sale",
    type: "house",
    bedrooms: 6,
    bathrooms: 7,
    area: 8500,
    city: "Lahore",
    area_name: "Model Town",
    address: "Block B, Model Town, Lahore",
    coordinates: { lat: 31.4816, lng: 74.3237 },
    images: [
      img("1600596542815-ffad4c1539a9"),
      img("1600585154340-be6161a56a0c"),
      img("1600607687939-ce8a6c25118c"),
      img("1600566753190-17f0baa2a6c3"),
    ],
    features: ["Swimming Pool", "Gym", "1 Kanal", "Imported Fittings", "Green Belt"],
    featured: true,
    premium: true,
    tier: "premium",
    agent: AGENTS[1],
    created_at: "2025-12-12",
  },
  {
    id: "p8",
    title: "Affordable 5 Marla House in Madina Town",
    description:
      "A well-constructed 5 Marla double-storey house in a peaceful neighborhood. Suitable for medium-sized families, with easy access to the main road.",
    price: 14500000,
    purpose: "sale",
    type: "house",
    bedrooms: 3,
    bathrooms: 3,
    area: 1625,
    city: "Faisalabad",
    area_name: "Madina Town",
    address: "Street 5, Madina Town, Faisalabad",
    coordinates: { lat: 31.4504, lng: 73.135 },
    images: [
      img("1568605114967-8130f3a36994"),
      img("1564013799919-ab600027ffc6"),
    ],
    features: ["Double Storey", "Car Porch", "Green Belt", "Near School"],
    featured: false,
    premium: false,
    tier: "standard",
    agent: AGENTS[3],
    created_at: "2025-11-30",
  },
  {
    id: "p9",
    title: "Commercial Shop on Main Boulevard",
    description:
      "High-footfall commercial shop on the main boulevard. Suitable for a retail outlet, restaurant, or office. Located in a busy commercial area with ample parking nearby.",
    price: 85000000,
    purpose: "sale",
    type: "commercial",
    bedrooms: 0,
    bathrooms: 2,
    area: 1800,
    city: "Islamabad",
    area_name: "F-7",
    address: "F-7 Markaz, Islamabad",
    coordinates: { lat: 33.7294, lng: 73.0931 },
    images: [
      img("1582407947304-fd86f028f716"),
      img("1497366216548-37526070297c"),
    ],
    features: ["Corner Shop", "High Footfall", "Main Road", "Power Backup"],
    featured: false,
    premium: true,
    tier: "premium",
    agent: AGENTS[0],
    created_at: "2025-12-08",
  },
  {
    id: "p10",
    title: "Serene Farmhouse in Chak Shehzad",
    description:
      "A 4 Kanal farmhouse with stables, a private orchard, and a swimming pool. Enjoy the tranquility of rural life just 20 minutes from the city center.",
    price: 320000000,
    purpose: "sale",
    type: "farmhouse",
    bedrooms: 6,
    bathrooms: 7,
    area: 108000,
    city: "Islamabad",
    area_name: "Bahria Town",
    address: "Chak Shehzad, Islamabad",
    coordinates: { lat: 33.6227, lng: 73.097 },
    images: [
      img("1600566753086-00f18efc2291"),
      img("1600585154526-990dced4db0d"),
      img("1600596542815-ffad4c1539a9"),
    ],
    features: ["4 Kanal", "Swimming Pool", "Stables", "Orchard", "Green House"],
    featured: true,
    premium: true,
    tier: "premium",
    agent: AGENTS[0],
    created_at: "2025-12-15",
  },
  {
    id: "p11",
    title: "Stylish Studio Apartment in DHA Phase 4",
    description:
      "Modern studio apartment with an open kitchen, walk-in closet, and a private balcony. Located in a gated community with parks and a mosque.",
    price: 95000,
    purpose: "rent",
    type: "apartment",
    bedrooms: 1,
    bathrooms: 1,
    area: 750,
    city: "Karachi",
    area_name: "DHA",
    address: "Phase 4, DHA, Karachi",
    coordinates: { lat: 24.8138, lng: 67.0305 },
    images: [
      img("1502672260266-1c1ef2d93688"),
      img("1554995207-c18c203602cb"),
    ],
    features: ["Gated Community", "Gym", "Balcony", "Parking", "Generator"],
    featured: false,
    premium: false,
    tier: "standard",
    agent: AGENTS[2],
    created_at: "2025-12-05",
  },
  {
    id: "p12",
    title: "1 Kanal Plot in DHA Bahawalpur Road",
    description:
      "A prime 1 Kanal plot in the sought-after DHA area. Ready for construction with all utilities available. Perfect for your dream home.",
    price: 55000000,
    purpose: "sale",
    type: "plot",
    bedrooms: 0,
    bathrooms: 0,
    area: 5445,
    city: "Multan",
    area_name: "DHA",
    address: "Sector X, DHA, Multan",
    coordinates: { lat: 30.1575, lng: 71.5249 },
    images: [
      img("1500382017468-9049fed747ef"),
      img("1564540583246-934409427776"),
    ],
    features: ["1 Kanal", "Corner", "Electricity", "Gas", "Wide Road"],
    featured: false,
    premium: false,
    tier: "standard",
    agent: AGENTS[3],
    created_at: "2025-12-02",
  },
  {
    id: "p13",
    title: "Luxury Penthouse in Gulberg Residencia",
    description:
      "A spectacular penthouse on the top floor with a private rooftop terrace, jacuzzi, and panoramic views of the Margalla Hills.",
    price: 450000,
    purpose: "rent",
    type: "apartment",
    bedrooms: 4,
    bathrooms: 5,
    area: 4200,
    city: "Islamabad",
    area_name: "Gulberg Greens",
    address: "Gulberg Residencia, Islamabad",
    coordinates: { lat: 33.5503, lng: 73.1976 },
    images: [
      img("1600585154340-be6161a56a0c"),
      img("1600596542815-ffad4c1539a9"),
      img("1600566753086-00f18efc2291"),
    ],
    features: ["Penthouse", "Rooftop Terrace", "Jacuzzi", "Margalla View", "Elevator"],
    featured: true,
    premium: true,
    tier: "premium",
    agent: AGENTS[0],
    created_at: "2025-12-18",
  },
  {
    id: "p14",
    title: "Family Home in Hayatabad Phase 6",
    description:
      "A comfortable 4-bedroom family home with a nice lawn, modern kitchen, and a separate guest suite. Located in a quiet street of Hayatabad.",
    price: 42000000,
    purpose: "sale",
    type: "house",
    bedrooms: 4,
    bathrooms: 4,
    area: 3500,
    city: "Peshawar",
    area_name: "Hayatabad",
    address: "Phase 6, Hayatabad, Peshawar",
    coordinates: { lat: 34.0147, lng: 71.5249 },
    images: [
      img("1605146769289-440113cc3d00"),
      img("1564013799919-ab600027ffc6"),
    ],
    features: ["Lawn", "Modern Kitchen", "Guest Suite", "Car Porch"],
    featured: false,
    premium: false,
    tier: "standard",
    agent: AGENTS[0],
    created_at: "2025-12-04",
  },
  {
    id: "p15",
    title: "Trendy Loft Office in IT Tower",
    description:
      "Modern loft-style office in the heart of the IT district. Open layout, exposed brick walls, and ample natural light. Includes a meeting room and break area.",
    price: 320000,
    purpose: "rent",
    type: "commercial",
    bedrooms: 0,
    bathrooms: 2,
    area: 1800,
    city: "Lahore",
    area_name: "Johar Town",
    address: "IT Tower, Johar Town, Lahore",
    coordinates: { lat: 31.4832, lng: 74.3015 },
    images: [
      img("1497366811353-6870744d04b2"),
      img("1497366754035-f200968a6e72"),
    ],
    features: ["Loft Style", "Open Layout", "Meeting Room", "IT Infrastructure"],
    featured: false,
    premium: false,
    tier: "standard",
    agent: AGENTS[1],
    created_at: "2025-12-11",
  },
  {
    id: "p16",
    title: "Elegant 7-Marla House on Canal Road",
    description:
      "A newly constructed house with modern finishes, located on the scenic Canal Road. Features a rooftop garden and a basement with a home theater.",
    price: 28500000,
    purpose: "sale",
    type: "house",
    bedrooms: 4,
    bathrooms: 5,
    area: 2400,
    city: "Gujranwala",
    area_name: "Model Town",
    address: "Canal Road, Model Town, Gujranwala",
    coordinates: { lat: 32.1877, lng: 74.1945 },
    images: [
      img("1600585154526-990dced4db0d"),
      img("1570129477492-45c003edd2be"),
    ],
    features: ["New Construction", "Rooftop Garden", "Basement Theater", "Canal View"],
    featured: false,
    premium: false,
    tier: "standard",
    agent: AGENTS[3],
    created_at: "2025-12-14",
  },
  {
    id: "p17",
    title: "40-Kanal Agricultural Land near Kala Shah Kaku",
    description:
      "Fertile agricultural land with a tube well and a small farmhouse. Ideal for farming, orchard plantation, or dairy farming.",
    price: 180000000,
    purpose: "sale",
    type: "farmhouse",
    bedrooms: 2,
    bathrooms: 2,
    area: 1080000,
    city: "Lahore",
    area_name: "DHA",
    address: "Near Kala Shah Kaku, Lahore",
    coordinates: { lat: 31.6216, lng: 74.3015 },
    images: [
      img("1500382017468-9049fed747ef"),
      img("1600585153086-00f18efc2291"),
    ],
    features: ["Fertile Land", "Tube Well", "Farmhouse", "Road Access"],
    featured: false,
    premium: true,
    tier: "premium",
    agent: AGENTS[1],
    created_at: "2025-12-09",
  },
  {
    id: "p18",
    title: "Smart 2-Bedroom Apartment in North Nazimabad",
    description:
      "Recently renovated apartment with new kitchen, bathrooms, and flooring. Walking distance to parks, schools, and the metro bus station.",
    price: 42000,
    purpose: "rent",
    type: "apartment",
    bedrooms: 2,
    bathrooms: 2,
    area: 1200,
    city: "Karachi",
    area_name: "North Nazimabad",
    address: "Block H, North Nazimabad, Karachi",
    coordinates: { lat: 24.9364, lng: 67.0466 },
    images: [
      img("1522708323590-d24dbb6b0267"),
      img("1554995207-c18c203602cb"),
    ],
    features: ["Renovated", "Near Metro", "Park Facing", "Covered Parking"],
    featured: false,
    premium: false,
    tier: "standard",
    agent: AGENTS[2],
    created_at: "2025-12-13",
  },
];

export const getCitiesList = () => CITIES.map((c) => c.name);
export const getAreasForCity = (city: string) =>
  CITIES.find((c) => c.name === city)?.areas || [];

export const getFeaturedProperties = () =>
  PROPERTIES.filter((p) => p.featured || p.premium).slice(0, 6);

export const getPremiumProperties = () =>
  PROPERTIES.filter((p) => p.premium);

export const getPropertyById = (id: string) =>
  PROPERTIES.find((p) => p.id === id);
