import { useState, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { CITIES, PROPERTY_TYPES } from "@/data/properties";
import { Search } from "./Icons";

export default function HomeSearchBar() {
  const navigate = useNavigate();
  const [purpose, setPurpose] = useState<"sale" | "rent">("sale");
  const [city, setCity] = useState("");
  const [type, setType] = useState("");
  const [q, setQ] = useState("");

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    params.set("purpose", purpose);
    if (city) params.set("city", city);
    if (type) params.set("type", type);
    if (q) params.set("q", q);
    navigate(`/search?${params.toString()}`);
  };

  return (
    <form
      onSubmit={onSubmit}
      className="rounded-2xl bg-white p-3 shadow-2xl ring-1 ring-black/5 md:p-4"
    >
      <div className="flex flex-wrap items-center gap-1 rounded-xl bg-slate-100 p-1">
        <button
          type="button"
          onClick={() => setPurpose("sale")}
          className={`flex-1 rounded-lg px-4 py-2 text-sm font-semibold transition ${
            purpose === "sale"
              ? "bg-white text-emerald-700 shadow"
              : "text-slate-600 hover:text-slate-900"
          }`}
        >
          Buy
        </button>
        <button
          type="button"
          onClick={() => setPurpose("rent")}
          className={`flex-1 rounded-lg px-4 py-2 text-sm font-semibold transition ${
            purpose === "rent"
              ? "bg-white text-emerald-700 shadow"
              : "text-slate-600 hover:text-slate-900"
          }`}
        >
          Rent
        </button>
      </div>

      <div className="mt-3 grid grid-cols-1 gap-2 md:grid-cols-4">
        <div className="md:col-span-2">
          <input
            type="text"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search by location, area, or project..."
            className="h-12 w-full rounded-xl border border-slate-200 bg-white px-4 text-sm text-slate-900 placeholder-slate-400 focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
          />
        </div>
        <select
          value={city}
          onChange={(e) => setCity(e.target.value)}
          className="h-12 w-full rounded-xl border border-slate-200 bg-white px-4 pr-8 text-sm text-slate-900 focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
        >
          <option value="">All Cities</option>
          {CITIES.map((c) => (
            <option key={c.name} value={c.name}>
              {c.name}
            </option>
          ))}
        </select>
        <select
          value={type}
          onChange={(e) => setType(e.target.value)}
          className="h-12 w-full rounded-xl border border-slate-200 bg-white px-4 pr-8 text-sm text-slate-900 focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
        >
          <option value="">All Types</option>
          {PROPERTY_TYPES.map((t) => (
            <option key={t.value} value={t.value}>
              {t.label}
            </option>
          ))}
        </select>
      </div>

      <button
        type="submit"
        className="mt-3 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 px-6 text-sm font-semibold text-white transition hover:bg-emerald-700"
      >
        <Search width={18} height={18} />
        Search Properties
      </button>
    </form>
  );
}
