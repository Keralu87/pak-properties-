import { Link, NavLink, useNavigate } from "react-router-dom";
import { useState } from "react";
import { useStore } from "@/utils/store";
import { Heart, Home as HomeIcon, LogOut, MapPin, Menu, User, X, Plus } from "./Icons";

export default function Header() {
  const navigate = useNavigate();
  const { user, logout, favorites } = useStore();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems = [
    { to: "/", label: "Home", icon: <HomeIcon width={16} height={16} /> },
    { to: "/buy", label: "Buy", icon: <MapPin width={16} height={16} /> },
    { to: "/rent", label: "Rent", icon: <MapPin width={16} height={16} /> },
    { to: "/commercial", label: "Commercial" },
    { to: "/plots", label: "Plots" },
    { to: "/farmhouses", label: "Farmhouses" },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-200 bg-white shadow-sm">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 lg:px-8">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-green-700 text-white">
            <HomeIcon width={20} height={20} />
          </div>
          <span className="text-xl font-bold tracking-tight text-slate-900">
            Pak<span className="text-emerald-600">Properties</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === "/"}
              className={({ isActive }) =>
                `flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition ${
                  isActive
                    ? "bg-emerald-50 text-emerald-700"
                    : "text-slate-700 hover:bg-slate-50"
                }`
              }
            >
              {item.icon}
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Link
            to="/submit"
            className="hidden items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-2 text-sm font-medium text-white transition hover:bg-emerald-700 lg:flex"
          >
            <Plus width={16} height={16} />
            List Property
          </Link>

          <Link
            to="/favorites"
            className="relative flex h-9 w-9 items-center justify-center rounded-lg text-slate-700 transition hover:bg-slate-100"
            aria-label="Favorites"
          >
            <Heart width={20} height={20} />
            {favorites.length > 0 && (
              <span className="absolute -top-1 -right-1 flex h-5 min-w-[1.25rem] items-center justify-center rounded-full bg-rose-600 px-1 text-xs font-bold text-white">
                {favorites.length}
              </span>
            )}
          </Link>

          {user ? (
            <div className="hidden items-center gap-2 lg:flex">
              {user.isAdmin && (
                <Link
                  to="/admin"
                  className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
                >
                  Admin
                </Link>
              )}
              <Link
                to="/account"
                className="flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
              >
                <img src={user.avatar} alt={user.name} className="h-6 w-6 rounded-full" />
                {user.name.split(" ")[0]}
              </Link>
              <button
                onClick={logout}
                className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-700 transition hover:bg-slate-100"
                aria-label="Logout"
              >
                <LogOut width={18} height={18} />
              </button>
            </div>
          ) : (
            <button
              onClick={() => navigate("/login")}
              className="hidden items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-50 lg:flex"
            >
              <User width={16} height={16} />
              Sign in
            </button>
          )}

          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-700 transition hover:bg-slate-100 lg:hidden"
            aria-label="Menu"
          >
            {mobileOpen ? <X width={20} height={20} /> : <Menu width={20} height={20} />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="border-t border-slate-200 bg-white lg:hidden">
          <div className="mx-auto flex max-w-7xl flex-col gap-1 px-4 py-3">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === "/"}
                onClick={() => setMobileOpen(false)}
                className={({ isActive }) =>
                  `rounded-lg px-3 py-2 text-sm font-medium transition ${
                    isActive
                      ? "bg-emerald-50 text-emerald-700"
                      : "text-slate-700 hover:bg-slate-50"
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
            <div className="my-2 h-px bg-slate-200" />
            <Link
              to="/submit"
              onClick={() => setMobileOpen(false)}
              className="rounded-lg bg-emerald-600 px-3 py-2 text-sm font-medium text-white"
            >
              List Property
            </Link>
            {user ? (
              <>
                <Link
                  to="/account"
                  onClick={() => setMobileOpen(false)}
                  className="rounded-lg px-3 py-2 text-sm font-medium text-slate-700"
                >
                  My Account
                </Link>
                <button
                  onClick={() => {
                    logout();
                    setMobileOpen(false);
                  }}
                  className="text-left rounded-lg px-3 py-2 text-sm font-medium text-rose-600"
                >
                  Sign out
                </button>
              </>
            ) : (
              <button
                onClick={() => {
                  navigate("/login");
                  setMobileOpen(false);
                }}
                className="text-left rounded-lg px-3 py-2 text-sm font-medium text-slate-700"
              >
                Sign in
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
