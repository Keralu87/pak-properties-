import { Link } from "react-router-dom";
import { useState } from "react";
import type { Property } from "@/data/properties";
import { useStore } from "@/utils/store";
import { formatArea, formatPrice } from "@/utils/format";
import { Bath, Bed, Heart, MapPin, Square, Star } from "./Icons";

export default function PropertyCard({ property, compact = false }: { property: Property; compact?: boolean }) {
  const { isFavorite, toggleFavorite } = useStore();
  const [imgIdx, setImgIdx] = useState(0);
  const fav = isFavorite(property.id);

  const tierBadge =
    property.tier === "premium" ? (
      <span className="bg-gradient-to-r from-amber-400 to-orange-500 text-white">
        <Star width={10} height={10} filled /> Premium
      </span>
    ) : property.tier === "featured" ? (
      <span className="bg-emerald-600 text-white">
        <Star width={10} height={10} filled /> Featured
      </span>
    ) : null;

  return (
    <article className="group overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-0.5 hover:shadow-lg">
      <div className="relative aspect-[4/3] overflow-hidden bg-slate-100">
        <img
          src={property.images[imgIdx]}
          alt={property.title}
          className="h-full w-full object-cover transition group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute top-3 left-3 flex flex-wrap gap-1">
          {tierBadge && (
            <span className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider">
              {tierBadge}
            </span>
          )}
          <span className="rounded-full bg-slate-900/80 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-white">
            For {property.purpose === "sale" ? "Sale" : "Rent"}
          </span>
        </div>
        <button
          onClick={(e) => {
            e.preventDefault();
            toggleFavorite(property.id);
          }}
          className={`absolute top-3 right-3 flex h-9 w-9 items-center justify-center rounded-full backdrop-blur transition ${
            fav
              ? "bg-rose-500 text-white"
              : "bg-white/90 text-slate-700 hover:bg-white"
          }`}
          aria-label={fav ? "Remove from favorites" : "Add to favorites"}
        >
          <Heart width={18} height={18} filled={fav} />
        </button>
        <div className="absolute bottom-3 left-3 flex gap-1">
          {property.images.map((_, i) => (
            <button
              key={i}
              onClick={(e) => {
                e.preventDefault();
                setImgIdx(i);
              }}
              className={`h-1.5 rounded-full transition-all ${
                i === imgIdx ? "w-6 bg-white" : "w-1.5 bg-white/60"
              }`}
              aria-label={`Image ${i + 1}`}
            />
          ))}
        </div>
      </div>

      <div className={`p-4 ${compact ? "space-y-2" : "space-y-3"}`}>
        <div className="flex items-start justify-between gap-2">
          <Link to={`/property/${property.id}`} className="flex-1">
            <h3
              className={`line-clamp-1 font-semibold text-slate-900 transition group-hover:text-emerald-700 ${
                compact ? "text-base" : "text-lg"
              }`}
            >
              {property.title}
            </h3>
          </Link>
        </div>

        <div className="flex items-center gap-1 text-sm text-slate-500">
          <MapPin width={14} height={14} />
          <span className="line-clamp-1">
            {property.area_name}, {property.city}
          </span>
        </div>

        <div className="text-2xl font-bold text-emerald-700">
          {formatPrice(property.price, property.purpose)}
        </div>

        {!compact && (
          <div className="flex items-center gap-4 border-t border-slate-100 pt-3 text-sm text-slate-600">
            {property.bedrooms > 0 && (
              <div className="flex items-center gap-1">
                <Bed width={16} height={16} />
                <span>{property.bedrooms} Beds</span>
              </div>
            )}
            {property.bathrooms > 0 && (
              <div className="flex items-center gap-1">
                <Bath width={16} height={16} />
                <span>{property.bathrooms} Baths</span>
              </div>
            )}
            <div className="flex items-center gap-1">
              <Square width={16} height={16} />
              <span>{formatArea(property.area)}</span>
            </div>
          </div>
        )}

        {!compact && (
          <div className="flex items-center justify-between border-t border-slate-100 pt-3">
            <div className="flex items-center gap-2">
              <img
                src={property.agent.avatar}
                alt={property.agent.name}
                className="h-8 w-8 rounded-full"
              />
              <div>
                <div className="text-xs font-medium text-slate-900">{property.agent.name}</div>
                <div className="text-[10px] text-slate-500">{property.agent.agency}</div>
              </div>
            </div>
            <Link
              to={`/property/${property.id}`}
              className="rounded-lg bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-700 transition hover:bg-emerald-100"
            >
              View Details
            </Link>
          </div>
        )}
      </div>
    </article>
  );
}
