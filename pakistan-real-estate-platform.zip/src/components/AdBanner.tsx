import { Megaphone } from "./Icons";

interface AdBannerProps {
  variant?: "horizontal" | "vertical" | "square";
  label?: string;
  className?: string;
}

export default function AdBanner({ variant = "horizontal", label = "Advertisement", className = "" }: AdBannerProps) {
  const dims = {
    horizontal: "h-32 lg:h-28",
    vertical: "h-96 w-full lg:w-64",
    square: "h-64 w-full",
  }[variant];

  const ads = [
    {
      top: "Buy Property with 0% Down Payment",
      sub: "Partner banks offering exclusive home financing deals for PakProperties users.",
      bg: "from-emerald-700 via-emerald-600 to-teal-600",
      accent: "bg-amber-400",
    },
    {
      top: "List your property free — for a limited time!",
      sub: "Get 30 days of premium exposure at no cost. Submit your listing today.",
      bg: "from-indigo-700 via-purple-700 to-fuchsia-600",
      accent: "bg-rose-400",
    },
    {
      top: "Move into your dream home with Pak Homes",
      sub: "Verified rentals across major cities with flexible lease terms.",
      bg: "from-orange-600 via-rose-600 to-pink-600",
      accent: "bg-white",
    },
  ];

  const ad = ads[Math.floor(Math.random() * ads.length)];

  return (
    <div
      className={`relative overflow-hidden rounded-2xl bg-gradient-to-br ${ad.bg} text-white shadow-md ${dims} ${className}`}
    >
      <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/10" />
      <div className="absolute -bottom-12 -left-8 h-40 w-40 rounded-full bg-white/10" />
      <div className="flex h-full flex-col justify-between p-5">
        <span className="inline-flex w-fit items-center gap-1 rounded-md bg-black/30 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider backdrop-blur">
          <Megaphone width={10} height={10} />
          {label}
        </span>
        <div>
          <h3 className="text-base font-bold leading-tight md:text-lg">{ad.top}</h3>
          <p className="mt-1 line-clamp-2 text-xs text-white/85 md:text-sm">{ad.sub}</p>
          <button className={`mt-3 inline-flex items-center gap-2 rounded-lg ${ad.accent} px-4 py-1.5 text-xs font-bold text-slate-900 shadow`}>
            Learn more →
          </button>
        </div>
      </div>
    </div>
  );
}
