import { useState } from "react";
import { CITIES, PROPERTY_TYPES, BEDROOM_OPTIONS } from "@/data/properties";
import type { ListingPurpose, PropertyType } from "@/data/properties";
import { Filter } from "./Icons";

export interface FilterState {
  purpose: ListingPurpose;
  city: string;
  area: string;
  type: PropertyType | "";
  bedrooms: string;
  minPrice: string;
  maxPrice: string;
  minArea: string;
  maxArea: string;
  tier: "" | "featured" | "premium";
  q: string;
}

export const defaultFilters: FilterState = {
  purpose: "sale",
  city: "",
  area: "",
  type: "",
  bedrooms: "any",
  minPrice: "",
  maxPrice: "",
  minArea: "",
  maxArea: "",
  tier: "",
  q: "",
};

interface Props {
  filters: FilterState;
  setFilters: (f: FilterState) => void;
  onClose?: () => void;
  isMobile?: boolean;
}

export default function FilterPanel({ filters, setFilters, onClose, isMobile }: Props) {
  const [open, setOpen] = useState(!isMobile);
  const areas = filters.city
    ? CITIES.find((c) => c.name === filters.city)?.areas || []
    : [];

  const update = (patch: Partial<FilterState>) => setFilters({ ...filters, ...patch });

  const clear = () => {
    setFilters({ ...defaultFilters, purpose: filters.purpose });
  };

  const activeCount = [
    filters.city,
    filters.area,
    filters.type,
    filters.bedrooms !== "any" ? filters.bedrooms : null,
    filters.minPrice,
    filters.maxPrice,
    filters.minArea,
    filters.maxArea,
    filters.tier,
    filters.q,
  ].filter(Boolean).length;

  return (
    <div className={`rounded-2xl border border-slate-200 bg-white ${isMobile ? "" : "lg:sticky lg:top-24"}`}>
      <button
        onClick={() => setOpen(!open)}
        className="flex w-full items-center justify-between border-b border-slate-200 px-4 py-3 text-left"
      >
        <span className="flex items-center gap-2 font-semibold text-slate-900">
          <Filter width={18} height={18} />
          Filters
          {activeCount > 0 && (
            <span className="rounded-full bg-emerald-600 px-2 py-0.5 text-xs font-bold text-white">
              {activeCount}
            </span>
          )}
        </span>
        <span className="text-xs text-slate-500">{open ? "Hide" : "Show"}</span>
      </button>

      {open && (
        <div className="space-y-5 p-4">
          <div>
            <label className="mb-2 block text-xs font-semibold text-slate-700">SEARCH</label>
            <input
              type="text"
              value={filters.q}
              onChange={(e) => update({ q: e.target.value })}
              placeholder="Keyword..."
              className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            />
          </div>

          <div>
            <label className="mb-2 block text-xs font-semibold text-slate-700">LISTING TYPE</label>
            <div className="flex gap-1 rounded-lg bg-slate-100 p-1">
              <button
                type="button"
                onClick={() => update({ purpose: "sale" })}
                className={`flex-1 rounded-md px-3 py-1.5 text-xs font-semibold transition ${
                  filters.purpose === "sale"
                    ? "bg-white text-emerald-700 shadow"
                    : "text-slate-600"
                }`}
              >
                For Sale
              </button>
              <button
                type="button"
                onClick={() => update({ purpose: "rent" })}
                className={`flex-1 rounded-md px-3 py-1.5 text-xs font-semibold transition ${
                  filters.purpose === "rent"
                    ? "bg-white text-emerald-700 shadow"
                    : "text-slate-600"
                }`}
              >
                For Rent
              </button>
            </div>
          </div>

          <div>
            <label className="mb-2 block text-xs font-semibold text-slate-700">CITY</label>
            <select
              value={filters.city}
              onChange={(e) => update({ city: e.target.value, area: "" })}
              className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            >
              <option value="">All Cities</option>
              {CITIES.map((c) => (
                <option key={c.name} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="mb-2 block text-xs font-semibold text-slate-700">AREA / LOCALITY</label>
            <select
              value={filters.area}
              onChange={(e) => update({ area: e.target.value })}
              disabled={!filters.city}
              className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 disabled:bg-slate-50 disabled:text-slate-400"
            >
              <option value="">All Areas</option>
              {areas.map((a) => (
                <option key={a} value={a}>
                  {a}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="mb-2 block text-xs font-semibold text-slate-700">PROPERTY TYPE</label>
            <select
              value={filters.type}
              onChange={(e) => update({ type: e.target.value as PropertyType | "" })}
              className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            >
              <option value="">All Types</option>
              {PROPERTY_TYPES.map((t) => (
                <option key={t.value} value={t.value}>
                  {t.icon} {t.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="mb-2 block text-xs font-semibold text-slate-700">BEDROOMS</label>
            <div className="grid grid-cols-3 gap-1">
              {BEDROOM_OPTIONS.map((b) => (
                <button
                  key={b.value}
                  type="button"
                  onClick={() => update({ bedrooms: b.value })}
                  className={`rounded-lg px-2 py-2 text-xs font-semibold transition ${
                    filters.bedrooms === b.value
                      ? "bg-emerald-600 text-white"
                      : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                  }`}
                >
                  {b.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="mb-2 block text-xs font-semibold text-slate-700">PRICE (PKR)</label>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                value={filters.minPrice}
                onChange={(e) => update({ minPrice: e.target.value })}
                placeholder="Min"
                className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
              <input
                type="number"
                value={filters.maxPrice}
                onChange={(e) => update({ maxPrice: e.target.value })}
                placeholder="Max"
                className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>
          </div>

          <div>
            <label className="mb-2 block text-xs font-semibold text-slate-700">AREA (SQFT)</label>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                value={filters.minArea}
                onChange={(e) => update({ minArea: e.target.value })}
                placeholder="Min"
                className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
              <input
                type="number"
                value={filters.maxArea}
                onChange={(e) => update({ maxArea: e.target.value })}
                placeholder="Max"
                className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>
          </div>

          <div>
            <label className="mb-2 block text-xs font-semibold text-slate-700">TIER</label>
            <div className="flex gap-1">
              {[
                { v: "" as const, l: "All" },
                { v: "featured" as const, l: "Featured" },
                { v: "premium" as const, l: "Premium" },
              ].map((t) => (
                <button
                  key={t.v || "all"}
                  type="button"
                  onClick={() => update({ tier: t.v })}
                  className={`flex-1 rounded-lg px-2 py-2 text-xs font-semibold transition ${
                    filters.tier === t.v
                      ? "bg-emerald-600 text-white"
                      : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                  }`}
                >
                  {t.l}
                </button>
              ))}
            </div>
          </div>

          <div className="flex gap-2 border-t border-slate-200 pt-4">
            <button
              type="button"
              onClick={clear}
              className="flex-1 rounded-lg border border-slate-200 px-3 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
            >
              Clear All
            </button>
            {isMobile && onClose && (
              <button
                type="button"
                onClick={onClose}
                className="flex-1 rounded-lg bg-emerald-600 px-3 py-2 text-sm font-semibold text-white transition hover:bg-emerald-700"
              >
                Apply
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
