import type { ReactNode, SVGProps } from "react";

const svgProps: SVGProps<SVGSVGElement> = {
  width: 20,
  height: 20,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round",
};

export const Home = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <path d="M3 12l9-9 9 9v9a2 2 0 0 1-2 2h-4v-7H10v7H6a2 2 0 0 1-2-2v-9z" />
  </svg>
);

export const Search = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <circle cx="11" cy="11" r="7" />
    <path d="M21 21l-4.3-4.3" />
  </svg>
);

export const Menu = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <path d="M3 6h18M3 12h18M3 18h18" />
  </svg>
);

export const X = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <path d="M18 6L6 18M6 6l12 12" />
  </svg>
);

export const Heart = (p: SVGProps<SVGSVGElement> & { filled?: boolean }): ReactNode => (
  <svg {...svgProps} fill={p.filled ? "currentColor" : "none"} {...p}>
    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 1 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
  </svg>
);

export const Bed = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <path d="M3 7v10M21 7v10M3 12h18M5 7h4v5H5zM15 7h4v5h-4zM3 17h18" />
  </svg>
);

export const Bath = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <path d="M9 6 6.5 8.5a2.121 2.121 0 1 0 3 3L9 9M3 19v2M21 19v2M3 16h18v-1a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4z" />
  </svg>
);

export const Square = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <rect x="3" y="3" width="18" height="18" rx="2" />
  </svg>
);

export const MapPin = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 1 1 18 0z" />
    <circle cx="12" cy="10" r="3" />
  </svg>
);

export const Phone = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z" />
  </svg>
);

export const Mail = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
    <polyline points="22,6 12,13 2,6" />
  </svg>
);

export const User = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
    <circle cx="12" cy="7" r="4" />
  </svg>
);

export const Building = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <rect x="4" y="2" width="16" height="20" rx="2" />
    <path d="M9 22v-4h6v4M8 6h2M8 10h2M8 14h2M14 6h2M14 10h2M14 14h2" />
  </svg>
);

export const TreePine = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <path d="M12 2L8 8h3l-3 6h3l-3 6h10l-3-6h3l-3-6h3z" />
  </svg>
);

export const Map = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6" />
    <line x1="8" y1="2" x2="8" y2="18" />
    <line x1="16" y1="6" x2="16" y2="22" />
  </svg>
);

export const Plus = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <line x1="12" y1="5" x2="12" y2="19" />
    <line x1="5" y1="12" x2="19" y2="12" />
  </svg>
);

export const Filter = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" />
  </svg>
);

export const ChevronDown = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <polyline points="6 9 12 15 18 9" />
  </svg>
);

export const ChevronLeft = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <polyline points="15 18 9 12 15 6" />
  </svg>
);

export const ChevronRight = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <polyline points="9 18 15 12 9 6" />
  </svg>
);

export const Star = (p: SVGProps<SVGSVGElement> & { filled?: boolean }): ReactNode => (
  <svg {...svgProps} fill={p.filled ? "currentColor" : "none"} {...p}>
    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
  </svg>
);

export const Shield = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
  </svg>
);

export const CheckCircle = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
    <polyline points="22 4 12 14.01 9 11.01" />
  </svg>
);

export const Camera = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
    <circle cx="12" cy="13" r="4" />
  </svg>
);

export const TrendingUp = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
    <polyline points="17 6 23 6 23 12" />
  </svg>
);

export const Calculator = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <rect x="4" y="2" width="16" height="20" rx="2" />
    <line x1="8" y1="6" x2="16" y2="6" />
    <line x1="8" y1="14" x2="8" y2="14" />
    <line x1="12" y1="14" x2="12" y2="14" />
    <line x1="16" y1="14" x2="16" y2="14" />
    <line x1="8" y1="18" x2="8" y2="18" />
    <line x1="12" y1="18" x2="12" y2="18" />
    <line x1="16" y1="18" x2="16" y2="18" />
  </svg>
);

export const LogOut = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
    <polyline points="16 17 21 12 16 7" />
    <line x1="21" y1="12" x2="9" y2="12" />
  </svg>
);

export const Eye = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);

export const Megaphone = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <path d="M3 11l18-7v18l-18-7z" />
  </svg>
);

export const Calendar = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
    <line x1="16" y1="2" x2="16" y2="6" />
    <line x1="8" y1="2" x2="8" y2="6" />
    <line x1="3" y1="10" x2="21" y2="10" />
  </svg>
);

export const Lock = (p: SVGProps<SVGSVGElement>): ReactNode => (
  <svg {...svgProps} {...p}>
    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
  </svg>
);
