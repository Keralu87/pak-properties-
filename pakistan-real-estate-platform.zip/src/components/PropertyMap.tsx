import { Map as MapIcon, MapPin } from "./Icons";

interface MapProps {
  lat: number;
  lng: number;
  address: string;
  height?: string;
}

export default function PropertyMap({ lat, lng, address, height = "400px" }: MapProps) {
  return (
    <div
      className="relative overflow-hidden rounded-2xl border border-slate-200 bg-slate-100"
      style={{ height }}
    >
      {/* Stylized embedded map placeholder that scales gracefully */}
      <div
        className="absolute inset-0 w-full h-full"
        style={{
          background: `linear-gradient(135deg, #e0f2e9 0%, #c5e4d3 50%, #93c5b3 100%)`,
        }}
      >
        {/* Roads */}
        <svg
          className="absolute inset-0 h-full w-full"
          viewBox="0 0 400 400"
          fill="none"
          preserveAspectRatio="none"
        >
          <path
            d="M0 100 L400 120 M0 250 L400 270 M100 0 L120 400 M280 0 L300 400"
            stroke="#fff"
            strokeWidth="14"
            strokeLinecap="round"
          />
          <path
            d="M0 100 L400 120 M0 250 L400 270 M100 0 L120 400 M280 0 L300 400"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeLinecap="round"
          />
          <circle cx="200" cy="200" r="60" fill="#a7f3d0" opacity="0.6" />
          <circle cx="200" cy="200" r="30" fill="#10b981" opacity="0.4" />
        </svg>

        {/* Pins scattered */}
        {[
          { x: 20, y: 25 },
          { x: 70, y: 60 },
          { x: 30, y: 75 },
          { x: 80, y: 30 },
          { x: 50, y: 50 },
        ].map((p, i) => (
          <div
            key={i}
            className="absolute flex flex-col items-center"
            style={{ left: `${p.x}%`, top: `${p.y}%` }}
          >
            <MapPin width={14} height={14} className="text-rose-500 drop-shadow" />
          </div>
        ))}

        {/* Selected pin */}
        <div
          className="absolute -translate-x-1/2 -translate-y-full transform"
          style={{ left: "50%", top: "50%" }}
        >
          <div className="flex flex-col items-center">
            <div className="rounded-full bg-emerald-600 px-3 py-1 text-xs font-bold text-white shadow-lg">
              Here
            </div>
            <div className="h-4 w-4 -translate-y-2 rotate-45 transform rounded-sm bg-emerald-600" />
          </div>
        </div>
      </div>

      <div className="absolute right-3 bottom-3 flex gap-2">
        <a
          href={`https://www.google.com/maps?q=${lat},${lng}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 rounded-lg bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-md transition hover:bg-slate-50"
        >
          <MapIcon width={16} height={16} />
          Open in Google Maps
        </a>
      </div>

      <div className="absolute left-3 top-3 rounded-lg bg-white/95 px-3 py-2 text-xs shadow-md">
        <div className="font-semibold text-slate-900">{address}</div>
        <div className="text-slate-500">
          {lat.toFixed(4)}, {lng.toFixed(4)}
        </div>
      </div>
    </div>
  );
}
