import { Link } from "react-router-dom";
import { Home as HomeIcon, Mail, MapPin, Phone } from "./Icons";

export default function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-slate-900 text-slate-300">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 lg:grid-cols-4 lg:px-8">
        <div>
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-green-700 text-white">
              <HomeIcon width={20} height={20} />
            </div>
            <span className="text-xl font-bold tracking-tight text-white">
              Pak<span className="text-emerald-400">Properties</span>
            </span>
          </Link>
          <p className="mt-4 text-sm text-slate-400">
            Pakistan's most trusted real estate marketplace. Buy, sell, and rent properties across all major cities.
          </p>
          <div className="mt-4 space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <MapPin width={16} height={16} />
              <span>Blue Area, Islamabad, Pakistan</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone width={16} height={16} />
              <span>+92 51 1234567</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail width={16} height={16} />
              <span>contact@pakproperties.pk</span>
            </div>
          </div>
        </div>

        <div>
          <h4 className="mb-4 font-semibold text-white">Quick Links</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/buy" className="hover:text-emerald-400">Properties for Sale</Link></li>
            <li><Link to="/rent" className="hover:text-emerald-400">Properties for Rent</Link></li>
            <li><Link to="/commercial" className="hover:text-emerald-400">Commercial</Link></li>
            <li><Link to="/plots" className="hover:text-emerald-400">Plots</Link></li>
            <li><Link to="/farmhouses" className="hover:text-emerald-400">Farmhouses</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="mb-4 font-semibold text-white">Cities</h4>
          <ul className="grid grid-cols-2 gap-y-2 text-sm">
            <li><Link to="/buy?city=Islamabad" className="hover:text-emerald-400">Islamabad</Link></li>
            <li><Link to="/buy?city=Karachi" className="hover:text-emerald-400">Karachi</Link></li>
            <li><Link to="/buy?city=Lahore" className="hover:text-emerald-400">Lahore</Link></li>
            <li><Link to="/buy?city=Rawalpindi" className="hover:text-emerald-400">Rawalpindi</Link></li>
            <li><Link to="/buy?city=Faisalabad" className="hover:text-emerald-400">Faisalabad</Link></li>
            <li><Link to="/buy?city=Peshawar" className="hover:text-emerald-400">Peshawar</Link></li>
            <li><Link to="/buy?city=Multan" className="hover:text-emerald-400">Multan</Link></li>
            <li><Link to="/buy?city=Gujranwala" className="hover:text-emerald-400">Gujranwala</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="mb-4 font-semibold text-white">Newsletter</h4>
          <p className="text-sm text-slate-400">
            Subscribe for the latest property listings and market insights.
          </p>
          <form className="mt-3 flex gap-2" onSubmit={(e) => e.preventDefault()}>
            <input
              type="email"
              placeholder="Email address"
              className="flex-1 rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
            />
            <button className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700">
              Subscribe
            </button>
          </form>
        </div>
      </div>

      <div className="border-t border-slate-800">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-4 text-sm text-slate-400 lg:flex-row lg:px-8">
          <p>© {new Date().getFullYear()} PakProperties. All rights reserved.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-emerald-400">Privacy Policy</a>
            <a href="#" className="hover:text-emerald-400">Terms of Service</a>
            <a href="#" className="hover:text-emerald-400">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
