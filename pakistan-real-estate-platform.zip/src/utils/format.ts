export const formatPrice = (price: number, purpose: "sale" | "rent") => {
  if (purpose === "rent") {
    return `PKR ${price.toLocaleString("en-PK")}/month`;
  }
  if (price >= 100000000) {
    return `PKR ${(price / 100000000).toFixed(2)} Crore`;
  }
  if (price >= 100000) {
    return `PKR ${(price / 100000).toFixed(2)} Lac`;
  }
  return `PKR ${price.toLocaleString("en-PK")}`;
};

export const formatArea = (area: number) =>
  area >= 43560 ? `${(area / 43560).toFixed(2)} Acres` : `${area.toLocaleString("en-PK")} sqft`;

export const formatDate = (date: string) => {
  return new Date(date).toLocaleDateString("en-PK", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
};
