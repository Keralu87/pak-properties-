import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar: string;
  isAdmin: boolean;
}

export interface Favorite {
  propertyId: string;
  addedAt: string;
}

const defaultUser: User = {
  id: "u1",
  name: "Ali Raza",
  email: "ali.raza@example.com",
  phone: "+92 300 1234567",
  avatar: "https://i.pravatar.cc/150?img=68",
  isAdmin: false,
};

interface StoreContext {
  user: User | null;
  favorites: string[];
  isAdmin: boolean;
  login: (email: string, password: string) => void;
  logout: () => void;
  toggleFavorite: (id: string) => void;
  isFavorite: (id: string) => boolean;
}

const StoreCtx = createContext<StoreContext | null>(null);

const FAV_KEY = "pakproperties-favorites";
const USER_KEY = "pakproperties-user";

export function StoreProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(USER_KEY);
    return saved ? JSON.parse(saved) : null;
  });
  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem(FAV_KEY);
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem(FAV_KEY, JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    if (user) {
      localStorage.setItem(USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(USER_KEY);
    }
  }, [user]);

  const login = (email: string, _password: string) => {
    // Mock login
    const isAdmin = email.includes("admin");
    setUser({ ...defaultUser, email, isAdmin });
  };

  const logout = () => setUser(null);

  const toggleFavorite = (id: string) =>
    setFavorites((f) => (f.includes(id) ? f.filter((x) => x !== id) : [...f, id]));

  const isFavorite = (id: string) => favorites.includes(id);

  return (
    <StoreCtx.Provider value={{ user, favorites, isAdmin: user?.isAdmin ?? false, login, logout, toggleFavorite, isFavorite }}>
      {children}
    </StoreCtx.Provider>
  );
}

export const useStore = () => {
  const ctx = useContext(StoreCtx);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
};
